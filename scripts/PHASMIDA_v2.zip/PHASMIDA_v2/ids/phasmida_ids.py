import os
import csv
import socket
import time
import json
import hmac
import hashlib

from collections import defaultdict, deque
from datetime import datetime, timezone


# ==========================================================
# CONFIGURACIÓN GENERAL
# ==========================================================

HOST = "0.0.0.0"
PORT = 10110

EVENTS_DIR = "events"

CSV_LOG = os.path.join(
    EVENTS_DIR,
    "phasmida_events.csv"
)

JSONL_LOG = os.path.join(
    EVENTS_DIR,
    "phasmida_events.jsonl"
)

SECRET_KEY = b"PHASMIDA_SECRET_2026"

# engine_node genera actualmente 17 tramas por ciclo.
# Se establece margen sobre el tráfico legítimo esperado.
MAX_MESSAGES_PER_SECOND = 25

MAX_MESSAGE_AGE_SECONDS = 10


# ==========================================================
# CONFIGURACIÓN DEL IDS
# ==========================================================

ALLOWED_SENTENCES = {
    "GGA",
    "RMC",
    "VTG",
    "HDG",
    "HDT",
    "HDM",
    "DBT",
    "DPT",
    "RPM",
    "XDR",
    "VDM",
    "VDO",
    "STATE"
}


ALLOWED_TALKERS = {
    "GP",       # GPS
    "GN",       # GNSS
    "HC",       # Compás
    "SD",       # Ecosonda
    "II",       # Instrumentación integrada
    "AI",       # AIS
    "PHASMIDA"  # Extensión propietaria PHASMIDA
}


# ==========================================================
# FUENTES DE RED AUTORIZADAS
# ==========================================================
#
# En la arquitectura actual los nodos de campo transmiten
# hacia PHASMIDA Core y Core reenvía los mensajes al IDS.
#
# Por tanto, desde el punto de vista de la capa de red,
# el origen legítimo observado por el IDS es PHASMIDA Core.
#
# 127.0.0.1 se mantiene exclusivamente para pruebas locales.
#
# La dirección Docker 10.50.10.20 corresponde al Core
# previsto en la red OT de PHASMIDA.

AUTHORIZED_NETWORK_SOURCES = {
    "127.0.0.1": "localhost_test",
    "10.50.10.20": "phasmida_core"
}


# ==========================================================
# IDENTIDADES LÓGICAS AUTORIZADAS
# ==========================================================
#
# La identidad del nodo original se transporta en el campo
# "sensor" del mensaje PHASMIDA Secure y queda incluida en
# el cálculo del HMAC.

AUTHORIZED_SENSORS = {
    "gps_node",
    "engine_node"
}


# ==========================================================
# UMBRALES DEL PROCESO OT
# ==========================================================

ENGINE_RPM_MIN = 0.0
ENGINE_RPM_MAX = 900.0

ENGINE_TEMP_MIN = 20.0
ENGINE_TEMP_MAX = 100.0

COOLANT_TEMP_MIN = 20.0
COOLANT_TEMP_MAX = 95.0

OIL_PRESSURE_MIN = 2.5
OIL_PRESSURE_MAX = 6.0

FUEL_PRESSURE_MIN = 2.0
FUEL_PRESSURE_MAX = 5.0

COOLING_PRESSURE_MIN = 1.5
COOLING_PRESSURE_MAX = 4.0

COOLING_TEMP_MIN = 20.0
COOLING_TEMP_MAX = 90.0

GENERATOR_FREQUENCY_MIN = 48.0
GENERATOR_FREQUENCY_MAX = 52.0


# ==========================================================
# UMBRALES DE COHERENCIA OT
# ==========================================================

FLOW_PRESENT_THRESHOLD = 10.0

GENERATOR_VOLTAGE_PRESENT_THRESHOLD = 50.0
GENERATOR_CURRENT_PRESENT_THRESHOLD = 5.0
GENERATOR_POWER_PRESENT_THRESHOLD = 5.0

ENGINE_RUNNING_RPM_THRESHOLD = 50.0


# ==========================================================
# ESTADO INTERNO DEL IDS
# ==========================================================
#
# Se utiliza únicamente para correlacionar distintas
# variables del proceso y detectar incoherencias.
#
# None significa que todavía no se ha recibido información
# suficiente para evaluar esa condición.

OT_STATE = {

    "propulsion": {
        "port_rpm": None,
        "port_status": None,

        "starboard_rpm": None,
        "starboard_status": None
    },

    "fuel": {
        "port_pump": None,
        "starboard_pump": None,

        "port_valve": None,
        "starboard_valve": None,

        "flow_l_min": None
    },

    "cooling": {
        "port_pump": None,
        "starboard_pump": None,

        "flow_l_min": None
    },

    "electrical": {
        "generator_running": None,

        "voltage_v": None,
        "current_a": None,
        "power_kw": None
    }
}


# Evita registrar la misma incoherencia en cada ciclo.
ACTIVE_COHERENCE_ALERTS = set()


# ==========================================================
# CHECKSUM NMEA / IEC 61162 / PHASMIDA
# ==========================================================

def nmea_checksum(body: str) -> str:

    value = 0

    for char in body:
        value ^= ord(char)

    return f"{value:02X}"


def validate_checksum(
    sentence: str
) -> tuple[bool, str]:

    sentence = sentence.strip()

    if (
        not sentence.startswith(("$", "!"))
        or "*" not in sentence
    ):

        return (
            False,
            "Formato NMEA/IEC 61162/PHASMIDA inválido"
        )

    try:

        body, received = sentence[
            1:
        ].split(
            "*",
            1
        )

        received = received[
            :2
        ].upper()

        calculated = nmea_checksum(
            body
        )

        if calculated != received:

            return (
                False,
                (
                    "Checksum inválido "
                    f"recibido={received}, "
                    f"calculado={calculated}"
                )
            )

        return True, "OK"

    except Exception as error:

        return (
            False,
            f"Error validando checksum: {error}"
        )


# ==========================================================
# CLASIFICACIÓN DE SENTENCIAS
# ==========================================================

def classify_sentence(
    sentence: str
) -> tuple[str, str]:

    try:

        body = sentence[
            1:
        ].split(
            "*",
            1
        )[0]

        header = body.split(
            ",",
            1
        )[0]

        # --------------------------------------------------
        # EXTENSIÓN PROPIETARIA PHASMIDA
        # --------------------------------------------------

        if header == "PHSMD":

            return (
                "STATE",
                "MAQUINARIA_OT"
            )

        sentence_type = header[2:]

        if sentence_type in {
            "RMC",
            "GGA",
            "VTG"
        }:

            return (
                sentence_type,
                "GNSS"
            )

        elif sentence_type in {
            "HDG",
            "HDT",
            "HDM"
        }:

            return (
                sentence_type,
                "RUMBO"
            )

        elif sentence_type in {
            "DBT",
            "DPT"
        }:

            return (
                sentence_type,
                "SONDA"
            )

        elif sentence_type in {
            "VDM",
            "VDO"
        }:

            return (
                sentence_type,
                "AIS"
            )

        elif sentence_type == "RPM":

            return (
                sentence_type,
                "PROPULSION"
            )

        elif sentence_type == "XDR":

            return (
                sentence_type,
                "MAQUINARIA_OT"
            )

        return (
            sentence_type,
            "DESCONOCIDO"
        )

    except Exception:

        return (
            "UNKNOWN",
            "DESCONOCIDO"
        )


# ==========================================================
# VALIDACIÓN DE CABECERA
# ==========================================================

def validate_nmea_header(
    sentence: str
):

    try:

        sentence = sentence.strip()

        if not sentence.startswith(
            ("$", "!")
        ):

            return (
                False,
                None,
                None,
                "Cabecera NMEA/IEC 61162 inválida"
            )

        body = sentence[
            1:
        ].split(
            "*",
            1
        )[0]

        header = body.split(
            ",",
            1
        )[0]

        # --------------------------------------------------
        # PHSMD
        # --------------------------------------------------

        if header == "PHSMD":

            fields = body.split(",")

            if (
                len(fields) < 4
                or fields[1] != "STATE"
            ):

                return (
                    False,
                    "PHASMIDA",
                    "STATE",
                    "Mensaje PHSMD inválido"
                )

            return (
                True,
                "PHASMIDA",
                "STATE",
                "OK"
            )

        # --------------------------------------------------
        # IEC 61162 / NMEA
        # --------------------------------------------------

        if len(header) < 5:

            return (
                False,
                None,
                None,
                f"Cabecera incompleta: {header}"
            )

        talker = header[:2]
        sentence_type = header[2:]

        errors = []

        if talker not in ALLOWED_TALKERS:

            errors.append(
                f"Talker ID no autorizado: {talker}"
            )

        if sentence_type not in ALLOWED_SENTENCES:

            errors.append(
                (
                    "Tipo de sentencia no permitido: "
                    f"{sentence_type}"
                )
            )

        if errors:

            return (
                False,
                talker,
                sentence_type,
                "; ".join(errors)
            )

        return (
            True,
            talker,
            sentence_type,
            "OK"
        )

    except Exception as error:

        return (
            False,
            None,
            None,
            (
                "Error validando cabecera "
                f"NMEA/IEC 61162: {error}"
            )
        )


# ==========================================================
# HMAC
# ==========================================================

def calculate_hmac(
    nmea_sentence,
    timestamp,
    sensor
):

    payload = (
        f"{nmea_sentence}|"
        f"{timestamp}|"
        f"{sensor}"
    )

    return hmac.new(
        SECRET_KEY,
        payload.encode("utf-8"),
        hashlib.sha256
    ).hexdigest()


def validate_hmac(
    message
):

    required_fields = [
        "sensor",
        "timestamp",
        "nmea",
        "hmac"
    ]

    for field in required_fields:

        if field not in message:

            return (
                False,
                (
                    "Campo ausente en mensaje "
                    f"seguro: {field}"
                )
            )

    expected = calculate_hmac(
        message["nmea"],
        message["timestamp"],
        message["sensor"]
    )

    received = message["hmac"]

    if not hmac.compare_digest(
        expected,
        received
    ):

        return (
            False,
            (
                "HMAC inválido. Posible "
                "manipulación o suplantación."
            )
        )

    return True, "OK"


# ==========================================================
# TIMESTAMP
# ==========================================================

def validate_timestamp(
    timestamp
):

    try:

        msg_time = datetime.fromisoformat(
            timestamp
        )

        now = datetime.now(
            timezone.utc
        )

        age = abs(
            (
                now - msg_time
            ).total_seconds()
        )

        if age > MAX_MESSAGE_AGE_SECONDS:

            return (
                False,
                (
                    "Timestamp fuera de ventana "
                    f"temporal: {age:.1f} s"
                )
            )

        return True, "OK"

    except Exception as error:

        return (
            False,
            f"Timestamp inválido: {error}"
        )


# ==========================================================
# GESTIÓN DE EVENTOS
# ==========================================================

def ensure_event_files():

    os.makedirs(
        EVENTS_DIR,
        exist_ok=True
    )

    if not os.path.exists(
        CSV_LOG
    ):

        with open(
            CSV_LOG,
            "w",
            newline="",
            encoding="utf-8"
        ) as file:

            writer = csv.DictWriter(
                file,
                fieldnames=[
                    "timestamp",
                    "alert_type",
                    "severity",
                    "source_ip",
                    "message",
                    "raw_sentence"
                ]
            )

            writer.writeheader()


def write_event(
    event
):

    ensure_event_files()

    with open(
        CSV_LOG,
        "a",
        newline="",
        encoding="utf-8"
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=[
                "timestamp",
                "alert_type",
                "severity",
                "source_ip",
                "message",
                "raw_sentence"
            ]
        )

        writer.writerow(
            event
        )

    with open(
        JSONL_LOG,
        "a",
        encoding="utf-8"
    ) as file:

        file.write(
            json.dumps(
                event,
                ensure_ascii=False
            )
            + "\n"
        )


def create_alert(
    alert_type,
    severity,
    source_ip,
    message,
    raw_sentence
):

    timestamp = datetime.now(
        timezone.utc
    ).isoformat()

    event = {
        "timestamp": timestamp,
        "alert_type": alert_type,
        "severity": severity,
        "source_ip": source_ip,
        "message": message,
        "raw_sentence": raw_sentence
    }

    write_event(
        event
    )

    print(
        "\n" + "=" * 70,
        flush=True
    )

    print(
        f"[ALERTA PHASMIDA] {timestamp}",
        flush=True
    )

    print(
        f"Tipo:      {alert_type}",
        flush=True
    )

    print(
        f"Severidad: {severity}",
        flush=True
    )

    print(
        f"Origen:    {source_ip}",
        flush=True
    )

    print(
        f"Mensaje:   {message}",
        flush=True
    )

    print(
        f"Trama:     {raw_sentence}",
        flush=True
    )

    print(
        "=" * 70 + "\n",
        flush=True
    )


# ==========================================================
# PHASMIDA SECURE
# ==========================================================

def parse_secure_message(
    raw_data
):

    try:

        decoded = raw_data.decode(
            "utf-8",
            errors="ignore"
        ).strip()

        message = json.loads(
            decoded
        )

        if not isinstance(
            message,
            dict
        ):

            return (
                None,
                decoded,
                (
                    "El mensaje recibido no es "
                    "un objeto JSON"
                )
            )

        return (
            message,
            decoded,
            None
        )

    except Exception as error:

        decoded = raw_data.decode(
            "utf-8",
            errors="ignore"
        ).strip()

        return (
            None,
            decoded,
            (
                "Mensaje no compatible con "
                "PHASMIDA Secure: "
                f"{error}"
            )
        )


# ==========================================================
# GESTIÓN DE ALERTAS DE COHERENCIA
# ==========================================================

def set_coherence_alert(
    alert_key: str,
    condition: bool,
    alert_type: str,
    severity: str,
    source_ip: str,
    message: str,
    sentence: str
) -> None:
    """
    Genera una alerta únicamente cuando aparece una nueva
    incoherencia.

    Cuando la condición vuelve a ser normal se elimina la
    marca interna, permitiendo detectar nuevamente el mismo
    problema si reaparece posteriormente.
    """

    if condition:

        if alert_key not in ACTIVE_COHERENCE_ALERTS:

            ACTIVE_COHERENCE_ALERTS.add(
                alert_key
            )

            create_alert(
                alert_type,
                severity,
                source_ip,
                message,
                sentence
            )

    else:

        ACTIVE_COHERENCE_ALERTS.discard(
            alert_key
        )


# ==========================================================
# COHERENCIA DEL PROCESO
# ==========================================================

def evaluate_process_coherence(
    source_ip: str,
    sentence: str
) -> None:

    fuel = OT_STATE["fuel"]
    cooling = OT_STATE["cooling"]
    electrical = OT_STATE["electrical"]
    propulsion = OT_STATE["propulsion"]

    # ------------------------------------------------------
    # COMBUSTIBLE:
    # ambas bombas paradas pero existe caudal significativo.
    # ------------------------------------------------------

    fuel_pumps_known = (
        fuel["port_pump"] is not None
        and fuel["starboard_pump"] is not None
        and fuel["flow_l_min"] is not None
    )

    if fuel_pumps_known:

        condition = (
            not fuel["port_pump"]
            and not fuel["starboard_pump"]
            and fuel["flow_l_min"]
            > FLOW_PRESENT_THRESHOLD
        )

        set_coherence_alert(
            "FUEL_FLOW_WITH_PUMPS_OFF",
            condition,
            "FUEL_PROCESS_COHERENCE_ANOMALY",
            "HIGH",
            source_ip,
            (
                "Se detecta caudal de combustible "
                f"({fuel['flow_l_min']:.2f} L/min) "
                "con ambas bombas detenidas"
            ),
            sentence
        )

    # ------------------------------------------------------
    # COMBUSTIBLE:
    # ambas válvulas cerradas pero existe caudal.
    # ------------------------------------------------------

    fuel_valves_known = (
        fuel["port_valve"] is not None
        and fuel["starboard_valve"] is not None
        and fuel["flow_l_min"] is not None
    )

    if fuel_valves_known:

        condition = (
            not fuel["port_valve"]
            and not fuel["starboard_valve"]
            and fuel["flow_l_min"]
            > FLOW_PRESENT_THRESHOLD
        )

        set_coherence_alert(
            "FUEL_FLOW_WITH_VALVES_CLOSED",
            condition,
            "FUEL_PROCESS_COHERENCE_ANOMALY",
            "HIGH",
            source_ip,
            (
                "Se detecta caudal de combustible "
                f"({fuel['flow_l_min']:.2f} L/min) "
                "con ambas válvulas cerradas"
            ),
            sentence
        )

    # ------------------------------------------------------
    # REFRIGERACIÓN:
    # bombas detenidas pero existe caudal.
    # ------------------------------------------------------

    cooling_known = (
        cooling["port_pump"] is not None
        and cooling["starboard_pump"] is not None
        and cooling["flow_l_min"] is not None
    )

    if cooling_known:

        condition = (
            not cooling["port_pump"]
            and not cooling["starboard_pump"]
            and cooling["flow_l_min"]
            > FLOW_PRESENT_THRESHOLD
        )

        set_coherence_alert(
            "COOLING_FLOW_WITH_PUMPS_OFF",
            condition,
            "COOLING_PROCESS_COHERENCE_ANOMALY",
            "HIGH",
            source_ip,
            (
                "Se detecta caudal de refrigeración "
                f"({cooling['flow_l_min']:.2f} L/min) "
                "con ambas bombas detenidas"
            ),
            sentence
        )

    # ------------------------------------------------------
    # GENERADOR:
    # declarado parado pero mantiene variables eléctricas.
    # ------------------------------------------------------

    generator_known = (
        electrical["generator_running"] is not None
        and electrical["voltage_v"] is not None
        and electrical["current_a"] is not None
        and electrical["power_kw"] is not None
    )

    if generator_known:

        condition = (
            not electrical["generator_running"]
            and (
                electrical["voltage_v"]
                > GENERATOR_VOLTAGE_PRESENT_THRESHOLD

                or electrical["current_a"]
                > GENERATOR_CURRENT_PRESENT_THRESHOLD

                or electrical["power_kw"]
                > GENERATOR_POWER_PRESENT_THRESHOLD
            )
        )

        set_coherence_alert(
            "GENERATOR_OUTPUT_WHILE_STOPPED",
            condition,
            "GENERATOR_PROCESS_COHERENCE_ANOMALY",
            "CRITICAL",
            source_ip,
            (
                "El generador figura detenido pero "
                "mantiene magnitudes eléctricas activas"
            ),
            sentence
        )

    # ------------------------------------------------------
    # MOTOR BABOR:
    # estado inválido pero RPM significativas.
    # ------------------------------------------------------

    port_known = (
        propulsion["port_status"] is not None
        and propulsion["port_rpm"] is not None
    )

    if port_known:

        condition = (
            propulsion["port_status"] != "A"
            and propulsion["port_rpm"]
            > ENGINE_RUNNING_RPM_THRESHOLD
        )

        set_coherence_alert(
            "PORT_ENGINE_STATUS_RPM",
            condition,
            "ENGINE_STATE_COHERENCE_ANOMALY",
            "HIGH",
            source_ip,
            (
                "Motor de babor declarado no operativo "
                f"con {propulsion['port_rpm']:.1f} RPM"
            ),
            sentence
        )

    # ------------------------------------------------------
    # MOTOR ESTRIBOR
    # ------------------------------------------------------

    starboard_known = (
        propulsion["starboard_status"] is not None
        and propulsion["starboard_rpm"] is not None
    )

    if starboard_known:

        condition = (
            propulsion["starboard_status"] != "A"
            and propulsion["starboard_rpm"]
            > ENGINE_RUNNING_RPM_THRESHOLD
        )

        set_coherence_alert(
            "STBD_ENGINE_STATUS_RPM",
            condition,
            "ENGINE_STATE_COHERENCE_ANOMALY",
            "HIGH",
            source_ip,
            (
                "Motor de estribor declarado no operativo "
                f"con {propulsion['starboard_rpm']:.1f} RPM"
            ),
            sentence
        )


# ==========================================================
# DETECCIÓN DE ANOMALÍAS OT - RPM
# ==========================================================

def check_range(
    value: float,
    minimum: float,
    maximum: float
) -> bool:

    return (
        minimum
        <= value
        <= maximum
    )


def analyze_rpm_sentence(
    sentence: str,
    source_ip: str
) -> None:

    try:

        body = sentence[
            1:
        ].split(
            "*",
            1
        )[0]

        fields = body.split(",")

        if len(fields) < 6:
            return

        source_type = fields[1]
        source_number = fields[2]

        rpm = float(
            fields[3]
        )

        status = fields[5]

        if source_type != "E":
            return

        if source_number == "1":

            engine_name = "estribor"

            OT_STATE[
                "propulsion"
            ]["starboard_rpm"] = rpm

            OT_STATE[
                "propulsion"
            ]["starboard_status"] = status

        elif source_number == "2":

            engine_name = "babor"

            OT_STATE[
                "propulsion"
            ]["port_rpm"] = rpm

            OT_STATE[
                "propulsion"
            ]["port_status"] = status

        else:

            engine_name = source_number

        if not check_range(
            rpm,
            ENGINE_RPM_MIN,
            ENGINE_RPM_MAX
        ):

            create_alert(
                "ENGINE_RPM_OUT_OF_RANGE",
                "CRITICAL",
                source_ip,
                (
                    "Régimen anómalo en motor "
                    f"{engine_name}: "
                    f"{rpm:.1f} RPM"
                ),
                sentence
            )

        evaluate_process_coherence(
            source_ip,
            sentence
        )

    except (
        ValueError,
        IndexError
    ):

        return


# ==========================================================
# DETECCIÓN DE ANOMALÍAS OT - XDR
# ==========================================================

def analyze_xdr_sentence(
    sentence: str,
    source_ip: str
) -> None:

    try:

        body = sentence[
            1:
        ].split(
            "*",
            1
        )[0]

        fields = body.split(",")

        values = fields[1:]

        for index in range(
            0,
            len(values),
            4
        ):

            group = values[
                index:index + 4
            ]

            if len(group) < 4:
                continue

            raw_value = group[1]
            name = group[3]

            try:

                value = float(
                    raw_value
                )

            except ValueError:

                continue

            # ----------------------------------------------
            # ESTADO INTERNO PARA CORRELACIÓN
            # ----------------------------------------------

            if name == "FUEL_FLOW":

                OT_STATE[
                    "fuel"
                ]["flow_l_min"] = value

            elif name == "COOL_FLOW":

                OT_STATE[
                    "cooling"
                ]["flow_l_min"] = value

            elif name == "GEN_VOLTAGE":

                OT_STATE[
                    "electrical"
                ]["voltage_v"] = value

            elif name == "GEN_CURRENT":

                OT_STATE[
                    "electrical"
                ]["current_a"] = value

            elif name == "GEN_POWER":

                OT_STATE[
                    "electrical"
                ]["power_kw"] = value

            # ----------------------------------------------
            # TEMPERATURA MOTOR BABOR
            # ----------------------------------------------

            if name == "ENG_PORT_TEMP":

                if not check_range(
                    value,
                    ENGINE_TEMP_MIN,
                    ENGINE_TEMP_MAX
                ):

                    create_alert(
                        "ENGINE_TEMPERATURE_ANOMALY",
                        "CRITICAL",
                        source_ip,
                        (
                            "Temperatura anómala en "
                            "motor de babor: "
                            f"{value:.2f} °C"
                        ),
                        sentence
                    )

            # ----------------------------------------------
            # TEMPERATURA MOTOR ESTRIBOR
            # ----------------------------------------------

            elif name == "ENG_STBD_TEMP":

                if not check_range(
                    value,
                    ENGINE_TEMP_MIN,
                    ENGINE_TEMP_MAX
                ):

                    create_alert(
                        "ENGINE_TEMPERATURE_ANOMALY",
                        "CRITICAL",
                        source_ip,
                        (
                            "Temperatura anómala en "
                            "motor de estribor: "
                            f"{value:.2f} °C"
                        ),
                        sentence
                    )

            # ----------------------------------------------
            # REFRIGERANTE BABOR
            # ----------------------------------------------

            elif name == "COOL_PORT_TEMP":

                if not check_range(
                    value,
                    COOLANT_TEMP_MIN,
                    COOLANT_TEMP_MAX
                ):

                    create_alert(
                        "COOLANT_TEMPERATURE_ANOMALY",
                        "HIGH",
                        source_ip,
                        (
                            "Temperatura anómala del "
                            "refrigerante de babor: "
                            f"{value:.2f} °C"
                        ),
                        sentence
                    )

            # ----------------------------------------------
            # REFRIGERANTE ESTRIBOR
            # ----------------------------------------------

            elif name == "COOL_STBD_TEMP":

                if not check_range(
                    value,
                    COOLANT_TEMP_MIN,
                    COOLANT_TEMP_MAX
                ):

                    create_alert(
                        "COOLANT_TEMPERATURE_ANOMALY",
                        "HIGH",
                        source_ip,
                        (
                            "Temperatura anómala del "
                            "refrigerante de estribor: "
                            f"{value:.2f} °C"
                        ),
                        sentence
                    )

            # ----------------------------------------------
            # PRESIÓN ACEITE BABOR
            # ----------------------------------------------

            elif name == "OIL_PORT_PRESS":

                # La presión de aceite se evalúa como anomalía
                # únicamente cuando el motor está declarado
                # operativo. Con el motor parado, una presión
                # próxima a cero es coherente con el proceso y
                # no constituye por sí sola un incidente de
                # ciberseguridad.
                port_status = OT_STATE[
                    "propulsion"
                ]["port_status"]

                if (
                    port_status == "A"
                    and not check_range(
                        value,
                        OIL_PRESSURE_MIN,
                        OIL_PRESSURE_MAX
                    )
                ):

                    create_alert(
                        "OIL_PRESSURE_ANOMALY",
                        "CRITICAL",
                        source_ip,
                        (
                            "Presión de aceite anómala "
                            "en motor de babor operativo: "
                            f"{value:.2f} bar"
                        ),
                        sentence
                    )

            # ----------------------------------------------
            # PRESIÓN ACEITE ESTRIBOR
            # ----------------------------------------------

            elif name == "OIL_STBD_PRESS":

                # Misma correlación para el motor de estribor:
                # presión nula con motor detenido es un estado
                # operacional coherente, no una alerta cyber.
                starboard_status = OT_STATE[
                    "propulsion"
                ]["starboard_status"]

                if (
                    starboard_status == "A"
                    and not check_range(
                        value,
                        OIL_PRESSURE_MIN,
                        OIL_PRESSURE_MAX
                    )
                ):

                    create_alert(
                        "OIL_PRESSURE_ANOMALY",
                        "CRITICAL",
                        source_ip,
                        (
                            "Presión de aceite anómala "
                            "en motor de estribor operativo: "
                            f"{value:.2f} bar"
                        ),
                        sentence
                    )

            # ----------------------------------------------
            # PRESIÓN COMBUSTIBLE
            # ----------------------------------------------

            elif name == "FUEL_PRESS":

                if not check_range(
                    value,
                    FUEL_PRESSURE_MIN,
                    FUEL_PRESSURE_MAX
                ):

                    create_alert(
                        "FUEL_PRESSURE_ANOMALY",
                        "HIGH",
                        source_ip,
                        (
                            "Presión de combustible "
                            "anómala: "
                            f"{value:.2f} bar"
                        ),
                        sentence
                    )

            # ----------------------------------------------
            # PRESIÓN REFRIGERACIÓN
            # ----------------------------------------------

            elif name == "COOL_PRESS":

                if not check_range(
                    value,
                    COOLING_PRESSURE_MIN,
                    COOLING_PRESSURE_MAX
                ):

                    create_alert(
                        "COOLING_PRESSURE_ANOMALY",
                        "HIGH",
                        source_ip,
                        (
                            "Presión anómala en el "
                            "sistema de refrigeración: "
                            f"{value:.2f} bar"
                        ),
                        sentence
                    )

            # ----------------------------------------------
            # TEMPERATURA REFRIGERACIÓN
            # ----------------------------------------------

            elif name == "COOL_SYS_TEMP":

                if not check_range(
                    value,
                    COOLING_TEMP_MIN,
                    COOLING_TEMP_MAX
                ):

                    create_alert(
                        "COOLING_TEMPERATURE_ANOMALY",
                        "HIGH",
                        source_ip,
                        (
                            "Temperatura anómala en el "
                            "sistema de refrigeración: "
                            f"{value:.2f} °C"
                        ),
                        sentence
                    )

            # ----------------------------------------------
            # FRECUENCIA GENERADOR
            # ----------------------------------------------

            elif name == "GEN_FREQ":

                if not check_range(
                    value,
                    GENERATOR_FREQUENCY_MIN,
                    GENERATOR_FREQUENCY_MAX
                ):

                    create_alert(
                        "GENERATOR_FREQUENCY_ANOMALY",
                        "CRITICAL",
                        source_ip,
                        (
                            "Frecuencia anómala del "
                            "generador: "
                            f"{value:.2f} Hz"
                        ),
                        sentence
                    )

        evaluate_process_coherence(
            source_ip,
            sentence
        )

    except (
        ValueError,
        IndexError
    ):

        return


# ==========================================================
# DETECCIÓN DE ANOMALÍAS OT - PHSMD
# ==========================================================

def analyze_phasmida_state(
    sentence: str,
    source_ip: str
) -> None:

    try:

        body = sentence[
            1:
        ].split(
            "*",
            1
        )[0]

        fields = body.split(",")

        if len(fields) < 4:
            return

        if (
            fields[0] != "PHSMD"
            or fields[1] != "STATE"
        ):

            return

        identifier = fields[2]
        raw_value = fields[3]

        if raw_value not in {
            "0",
            "1"
        }:

            create_alert(
                "INVALID_DISCRETE_STATE",
                "HIGH",
                source_ip,
                (
                    "Valor discreto PHASMIDA "
                    f"no válido: {raw_value}"
                ),
                sentence
            )

            return

        value = (
            raw_value == "1"
        )

        if identifier == "FUEL_PORT_PUMP":

            OT_STATE[
                "fuel"
            ]["port_pump"] = value

        elif identifier == "FUEL_STBD_PUMP":

            OT_STATE[
                "fuel"
            ]["starboard_pump"] = value

        elif identifier == "FUEL_PORT_VALVE":

            OT_STATE[
                "fuel"
            ]["port_valve"] = value

        elif identifier == "FUEL_STBD_VALVE":

            OT_STATE[
                "fuel"
            ]["starboard_valve"] = value

        elif identifier == "COOL_PORT_PUMP":

            OT_STATE[
                "cooling"
            ]["port_pump"] = value

        elif identifier == "COOL_STBD_PUMP":

            OT_STATE[
                "cooling"
            ]["starboard_pump"] = value

        elif identifier == "GEN_RUNNING":

            OT_STATE[
                "electrical"
            ]["generator_running"] = value

        else:

            create_alert(
                "UNKNOWN_PHASMIDA_STATE",
                "MEDIUM",
                source_ip,
                (
                    "Identificador de estado PHASMIDA "
                    f"desconocido: {identifier}"
                ),
                sentence
            )

            return

        evaluate_process_coherence(
            source_ip,
            sentence
        )

    except (
        ValueError,
        IndexError
    ):

        return


# ==========================================================
# ANÁLISIS GENERAL DEL PROCESO OT
# ==========================================================

def analyze_ot_process(
    sentence: str,
    sentence_type: str | None,
    source_ip: str
) -> None:

    if sentence_type == "RPM":

        analyze_rpm_sentence(
            sentence,
            source_ip
        )

    elif sentence_type == "XDR":

        analyze_xdr_sentence(
            sentence,
            source_ip
        )

    elif sentence_type == "STATE":

        analyze_phasmida_state(
            sentence,
            source_ip
        )


# ==========================================================
# PROGRAMA PRINCIPAL
# ==========================================================

def main():

    sock = socket.socket(
        socket.AF_INET,
        socket.SOCK_DGRAM
    )

    sock.bind(
        (
            HOST,
            PORT
        )
    )

    print("=" * 70)
    print("PHASMIDA IDS")
    print("=" * 70)

    print(
        f"Escuchando en UDP "
        f"{HOST}:{PORT}",
        flush=True
    )

    print(
        "Fuentes de red autorizadas: "
        f"{AUTHORIZED_NETWORK_SOURCES}",
        flush=True
    )

    print(
        "Sensores autorizados: "
        f"{sorted(AUTHORIZED_SENSORS)}",
        flush=True
    )

    print(
        "Modo seguro: HMAC-SHA256 activado",
        flush=True
    )

    print(
        "Detección OT y coherencia de proceso: activadas",
        flush=True
    )

    print("=" * 70)

    packet_times = defaultdict(
        deque
    )

    flood_active = set()

    try:

        while True:

            data, addr = sock.recvfrom(
                4096
            )

            source_ip = addr[0]
            source_port = addr[1]

            now = time.time()

            (
                message,
                raw_payload,
                parse_error
            ) = parse_secure_message(
                data
            )

            # ==============================================
            # FORMATO PHASMIDA SECURE
            # ==============================================

            if parse_error:

                create_alert(
                    "INVALID_SECURE_FORMAT",
                    "HIGH",
                    source_ip,
                    parse_error,
                    raw_payload
                )

                continue

            required_fields = {
                "sensor",
                "timestamp",
                "nmea",
                "hmac"
            }

            if not required_fields.issubset(
                message
            ):

                missing_fields = (
                    required_fields
                    - set(message)
                )

                create_alert(
                    "MISSING_SECURE_FIELDS",
                    "HIGH",
                    source_ip,
                    (
                        "Campos obligatorios "
                        "ausentes: "
                        f"{sorted(missing_fields)}"
                    ),
                    raw_payload
                )

                continue

            sensor = str(
                message["sensor"]
            )

            # ==============================================
            # VALIDACIONES DE SEGURIDAD
            # ==============================================

            hmac_valid, hmac_msg = (
                validate_hmac(
                    message
                )
            )

            timestamp_valid, timestamp_msg = (
                validate_timestamp(
                    message["timestamp"]
                )
            )

            sentence = str(
                message["nmea"]
            ).strip()

            (
                valid_checksum,
                checksum_msg
            ) = validate_checksum(
                sentence
            )

            (
                header_valid,
                talker_id,
                sentence_type,
                header_msg
            ) = validate_nmea_header(
                sentence
            )

            (
                classified_type,
                category
            ) = classify_sentence(
                sentence
            )

            # ==============================================
            # LOG DE RECEPCIÓN
            # ==============================================

            print(
                f"[RX] {source_ip}:{source_port} | "
                f"Sensor={sensor} | "
                f"Talker={talker_id or 'UNKNOWN'} | "
                f"{classified_type}/{category} | "
                f"Header="
                f"{'OK' if header_valid else 'FAIL'} | "
                f"HMAC="
                f"{'OK' if hmac_valid else 'FAIL'} | "
                f"Checksum="
                f"{'OK' if valid_checksum else 'FAIL'} | "
                f"{sentence}",
                flush=True
            )

            # ==============================================
            # ORIGEN DE RED
            # ==============================================

            if (
                source_ip
                not in AUTHORIZED_NETWORK_SOURCES
            ):

                create_alert(
                    "UNAUTHORIZED_NETWORK_SOURCE",
                    "HIGH",
                    source_ip,
                    (
                        "Datagrama recibido desde una "
                        "fuente de red no autorizada"
                    ),
                    sentence
                )

            # ==============================================
            # IDENTIDAD LÓGICA DEL SENSOR
            # ==============================================

            if sensor not in AUTHORIZED_SENSORS:

                create_alert(
                    "UNAUTHORIZED_SENSOR",
                    "HIGH",
                    source_ip,
                    (
                        "Identidad lógica de sensor "
                        f"no autorizada: {sensor}"
                    ),
                    sentence
                )

            # ==============================================
            # CABECERA
            # ==============================================

            if not header_valid:

                create_alert(
                    "INVALID_NMEA_HEADER",
                    "HIGH",
                    source_ip,
                    header_msg,
                    sentence
                )

            # ==============================================
            # HMAC
            # ==============================================

            if not hmac_valid:

                create_alert(
                    "INVALID_HMAC",
                    "CRITICAL",
                    source_ip,
                    hmac_msg,
                    sentence
                )

            # ==============================================
            # TIMESTAMP
            # ==============================================

            if not timestamp_valid:

                create_alert(
                    "INVALID_TIMESTAMP",
                    "HIGH",
                    source_ip,
                    timestamp_msg,
                    sentence
                )

            # ==============================================
            # CHECKSUM
            # ==============================================

            if not valid_checksum:

                create_alert(
                    "INVALID_CHECKSUM",
                    "MEDIUM",
                    source_ip,
                    checksum_msg,
                    sentence
                )

            # ==============================================
            # FLOODING
            # ==============================================

            # Se contabiliza por identidad lógica del sensor,
            # ya que todos los mensajes llegan al IDS a través
            # de PHASMIDA Core.

            times = packet_times[
                sensor
            ]

            times.append(
                now
            )

            while (
                times
                and now - times[0] > 1
            ):

                times.popleft()

            if (
                len(times)
                > MAX_MESSAGES_PER_SECOND
            ):

                if sensor not in flood_active:

                    flood_active.add(
                        sensor
                    )

                    create_alert(
                        "NMEA_IEC61162_FLOOD",
                        "HIGH",
                        source_ip,
                        (
                            "Exceso de tráfico procedente "
                            f"de {sensor}: "
                            f"{len(times)} tramas/s"
                        ),
                        sentence
                    )

            else:

                flood_active.discard(
                    sensor
                )

            # ==============================================
            # ANÁLISIS DEL PROCESO OT
            # ==============================================
            #
            # Solo se aceptan datos de proceso que hayan
            # superado las validaciones esenciales.

            if (
                header_valid
                and valid_checksum
                and hmac_valid
                and timestamp_valid
                and sensor in AUTHORIZED_SENSORS
                and source_ip
                in AUTHORIZED_NETWORK_SOURCES
            ):

                analyze_ot_process(
                    sentence,
                    sentence_type,
                    source_ip
                )

    except KeyboardInterrupt:

        print(
            "\nPHASMIDA IDS detenido.",
            flush=True
        )

    finally:

        sock.close()


if __name__ == "__main__":
    main()