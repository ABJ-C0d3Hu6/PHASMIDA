import csv
import json
from datetime import datetime, timezone
from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas


# ==========================================================
# CONFIGURACIÓN
# ==========================================================

EVENTS_FILE = Path("events/phasmida_events.csv")
REPORTS_DIR = Path("reports")

CSV_FIELDS = [
    "timestamp",
    "alert_type",
    "severity",
    "source_ip",
    "message",
    "raw_sentence"
]


# ==========================================================
# UTILIDADES
# ==========================================================

def severity_score(severity):
    return {
        "LOW": 1,
        "MEDIUM": 2,
        "HIGH": 3,
        "CRITICAL": 4
    }.get(str(severity).strip().upper(), 0)


# ==========================================================
# CARGA DE EVENTOS
# ==========================================================

def load_events():
    """
    Carga los eventos generados por el IDS.

    El fichero CSV utilizado por PHASMIDA no contiene una
    fila de cabecera, por lo que los nombres de las columnas
    se especifican explícitamente.
    """

    if not EVENTS_FILE.exists():
        print(f"[PHASMIDA] No existe el fichero de eventos: {EVENTS_FILE}")
        return []

    with EVENTS_FILE.open(
        "r",
        encoding="utf-8",
        newline=""
    ) as f:

        reader = csv.DictReader(
            f,
            fieldnames=CSV_FIELDS
        )

        events = []

        for event in reader:

            # Ignorar líneas completamente vacías
            if not any(event.values()):
                continue

            # Normalización básica
            event["timestamp"] = (
                event.get("timestamp") or ""
            ).strip()

            event["alert_type"] = (
                event.get("alert_type") or ""
            ).strip()

            event["severity"] = (
                event.get("severity") or ""
            ).strip().upper()

            event["source_ip"] = (
                event.get("source_ip") or ""
            ).strip()

            event["message"] = (
                event.get("message") or ""
            ).strip()

            event["raw_sentence"] = (
                event.get("raw_sentence") or ""
            ).strip()

            events.append(event)

        return events


# ==========================================================
# CONSTRUCCIÓN DEL INFORME
# ==========================================================

def build_report_data(events):

    critical = sum(
        1 for e in events
        if e.get("severity") == "CRITICAL"
    )

    high = sum(
        1 for e in events
        if e.get("severity") == "HIGH"
    )

    medium = sum(
        1 for e in events
        if e.get("severity") == "MEDIUM"
    )

    low = sum(
        1 for e in events
        if e.get("severity") == "LOW"
    )

    events_sorted = sorted(
        events,
        key=lambda e: severity_score(
            e.get("severity", "")
        ),
        reverse=True
    )

    return {
        "report_type": "PHASMIDA Incident Report",

        "generated_at_utc": (
            datetime.now(timezone.utc).isoformat()
        ),

        "total_events": len(events),

        "severity_summary": {
            "CRITICAL": critical,
            "HIGH": high,
            "MEDIUM": medium,
            "LOW": low
        },

        "most_critical_event": (
            events_sorted[0]
            if events_sorted
            else None
        ),

        "events": events,

        "recommendations": [
            "Verificar el origen del tráfico no autorizado.",
            "Mantener el filtrado IPTables activo.",
            "Revisar la clave compartida HMAC-SHA256.",
            "Analizar las tramas NMEA asociadas al incidente.",
            "Conservar este informe como evidencia del experimento."
        ]
    }


# ==========================================================
# INFORME JSON
# ==========================================================

def save_json(report_data, path):

    path.write_text(
        json.dumps(
            report_data,
            indent=4,
            ensure_ascii=False
        ),
        encoding="utf-8"
    )


# ==========================================================
# INFORME TXT
# ==========================================================

def save_txt(report_data, path):

    lines = []

    lines.append("=" * 70)
    lines.append("PHASMIDA INCIDENT REPORT")
    lines.append("=" * 70)
    lines.append("")

    lines.append(
        f"Fecha de generación: "
        f"{report_data['generated_at_utc']}"
    )

    lines.append(
        f"Número total de eventos: "
        f"{report_data['total_events']}"
    )

    lines.append("")
    lines.append("RESUMEN DE SEVERIDAD")
    lines.append("-" * 70)

    for sev, count in report_data["severity_summary"].items():
        lines.append(
            f"  {sev}: {count}"
        )

    top = report_data["most_critical_event"]

    if top:

        lines.append("")
        lines.append("EVENTO MÁS CRÍTICO")
        lines.append("-" * 70)

        lines.append(
            f"Timestamp: {top.get('timestamp', '')}"
        )

        lines.append(
            f"Tipo:      {top.get('alert_type', '')}"
        )

        lines.append(
            f"Severidad: {top.get('severity', '')}"
        )

        lines.append(
            f"Origen:    {top.get('source_ip', '')}"
        )

        lines.append(
            f"Mensaje:   {top.get('message', '')}"
        )

        lines.append(
            f"Trama:     {top.get('raw_sentence', '')}"
        )

    lines.append("")
    lines.append("CRONOLOGÍA DE EVENTOS")
    lines.append("-" * 70)

    for e in report_data["events"]:

        lines.append(
            f"[{e.get('timestamp', '')}] "
            f"{e.get('severity', '')} | "
            f"{e.get('alert_type', '')} | "
            f"{e.get('source_ip', '')} | "
            f"{e.get('message', '')}"
        )

    lines.append("")
    lines.append("RECOMENDACIONES")
    lines.append("-" * 70)

    for rec in report_data["recommendations"]:
        lines.append(
            f"- {rec}"
        )

    path.write_text(
        "\n".join(lines),
        encoding="utf-8"
    )


# ==========================================================
# INFORME PDF
# ==========================================================

def save_pdf(report_data, path):

    c = canvas.Canvas(
        str(path),
        pagesize=A4
    )

    width, height = A4

    y = height - 50

    def write_line(
        text,
        size=10,
        bold=False
    ):
        nonlocal y

        if y < 60:
            c.showPage()
            y = height - 50

        font = (
            "Helvetica-Bold"
            if bold
            else "Helvetica"
        )

        c.setFont(
            font,
            size
        )

        c.drawString(
            50,
            y,
            str(text)[:115]
        )

        y -= 16

    # ------------------------------------------------------
    # CABECERA
    # ------------------------------------------------------

    write_line(
        "PHASMIDA INCIDENT REPORT",
        16,
        True
    )

    write_line(
        "=" * 90
    )

    write_line(
        f"Fecha de generación: "
        f"{report_data['generated_at_utc']}"
    )

    write_line(
        f"Número total de eventos: "
        f"{report_data['total_events']}"
    )

    write_line("")

    # ------------------------------------------------------
    # RESUMEN
    # ------------------------------------------------------

    write_line(
        "RESUMEN DE SEVERIDAD",
        12,
        True
    )

    for sev, count in report_data["severity_summary"].items():

        write_line(
            f"{sev}: {count}"
        )

    # ------------------------------------------------------
    # EVENTO MÁS CRÍTICO
    # ------------------------------------------------------

    top = report_data["most_critical_event"]

    if top:

        write_line("")

        write_line(
            "EVENTO MÁS CRÍTICO",
            12,
            True
        )

        write_line(
            f"Timestamp: "
            f"{top.get('timestamp', '')}"
        )

        write_line(
            f"Tipo: "
            f"{top.get('alert_type', '')}"
        )

        write_line(
            f"Severidad: "
            f"{top.get('severity', '')}"
        )

        write_line(
            f"Origen: "
            f"{top.get('source_ip', '')}"
        )

        write_line(
            f"Mensaje: "
            f"{top.get('message', '')}"
        )

        write_line(
            f"Trama: "
            f"{top.get('raw_sentence', '')}"
        )

    # ------------------------------------------------------
    # CRONOLOGÍA
    # ------------------------------------------------------

    write_line("")

    write_line(
        "CRONOLOGÍA DE EVENTOS",
        12,
        True
    )

    for e in report_data["events"]:

        write_line(
            f"[{e.get('timestamp', '')}] "
            f"{e.get('severity', '')} | "
            f"{e.get('alert_type', '')} | "
            f"{e.get('source_ip', '')}"
        )

        write_line(
            f"  {e.get('message', '')}"
        )

    # ------------------------------------------------------
    # RECOMENDACIONES
    # ------------------------------------------------------

    write_line("")

    write_line(
        "RECOMENDACIONES",
        12,
        True
    )

    for rec in report_data["recommendations"]:

        write_line(
            f"- {rec}"
        )

    c.save()


# ==========================================================
# GENERACIÓN DE INFORMES
# ==========================================================

def generate_report():

    REPORTS_DIR.mkdir(
        exist_ok=True
    )

    events = load_events()

    if not events:
        print(
            "[PHASMIDA] No se han encontrado eventos "
            "para incluir en el informe."
        )
        return

    report_data = build_report_data(
        events
    )

    now = datetime.now(
        timezone.utc
    ).strftime(
        "%Y%m%d_%H%M%S"
    )

    txt_path = (
        REPORTS_DIR /
        f"incident_report_{now}.txt"
    )

    json_path = (
        REPORTS_DIR /
        f"incident_report_{now}.json"
    )

    pdf_path = (
        REPORTS_DIR /
        f"incident_report_{now}.pdf"
    )

    save_txt(
        report_data,
        txt_path
    )

    save_json(
        report_data,
        json_path
    )

    save_pdf(
        report_data,
        pdf_path
    )

    print("")
    print("=" * 60)
    print("PHASMIDA - GENERACIÓN DE INFORME DE INCIDENTES")
    print("=" * 60)

    print(
        f"Eventos procesados: "
        f"{report_data['total_events']}"
    )

    print(
        f"CRITICAL: "
        f"{report_data['severity_summary']['CRITICAL']}"
    )

    print(
        f"HIGH:     "
        f"{report_data['severity_summary']['HIGH']}"
    )

    print(
        f"MEDIUM:   "
        f"{report_data['severity_summary']['MEDIUM']}"
    )

    print(
        f"LOW:      "
        f"{report_data['severity_summary']['LOW']}"
    )

    print("")
    print(f"TXT generado:  {txt_path}")
    print(f"JSON generado: {json_path}")
    print(f"PDF generado:  {pdf_path}")
    print("=" * 60)
    print("")


# ==========================================================
# MAIN
# ==========================================================

if __name__ == "__main__":
    generate_report()