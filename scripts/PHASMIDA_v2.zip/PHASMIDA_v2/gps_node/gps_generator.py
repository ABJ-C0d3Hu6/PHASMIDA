print("GPS Node iniciado")
