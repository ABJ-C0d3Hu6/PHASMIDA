import subprocess
from datetime import datetime, timezone
from pathlib import Path

import altair as alt
import pandas as pd
import streamlit as st


# ==========================================================
# CONFIGURACIÓN
# ==========================================================

EVENTS_FILE = Path("events/phasmida_events.csv")
REPORTS_DIR = Path("reports")

ACTIVE_ALERT_WINDOW_SECONDS = 30


# ==========================================================
# CONFIGURACIÓN STREAMLIT
# ==========================================================

st.set_page_config(
    page_title="PHASMIDA SIEM",
    page_icon="🛡️",
    layout="wide"
)

st.title("🛡️ PHASMIDA SIEM")

st.caption(
    "Monitorización de seguridad del entorno marítimo OT · "
    "NMEA 0183 · IEC 61162 · Cámara de máquinas"
)


# ==========================================================
# CARGA DE EVENTOS
# ==========================================================

@st.cache_data(ttl=2)
def load_events():

    columns = [
        "timestamp",
        "alert_type",
        "severity",
        "source_ip",
        "message",
        "raw_sentence"
    ]

    if not EVENTS_FILE.exists():

        return pd.DataFrame(
            columns=columns
        )

    try:

        df = pd.read_csv(
            EVENTS_FILE
        )

    except Exception:

        return pd.DataFrame(
            columns=columns
        )

    if df.empty:

        return pd.DataFrame(
            columns=columns
        )

    df["timestamp"] = pd.to_datetime(
        df["timestamp"],
        errors="coerce",
        utc=True
    )

    df = df.dropna(
        subset=["timestamp"]
    )

    df = df.sort_values(
        "timestamp",
        ascending=False
    )

    return df


# ==========================================================
# SEVERIDAD
# ==========================================================

def severity_rank(
    severity
):

    ranks = {
        "CRITICAL": 4,
        "HIGH": 3,
        "MEDIUM": 2,
        "LOW": 1,
        "INFO": 0
    }

    return ranks.get(
        str(severity).upper(),
        0
    )


# ==========================================================
# ALERTAS ACTIVAS
# ==========================================================

def get_active_events(
    df
):

    if df.empty:

        return df

    now = pd.Timestamp.now(
        tz="UTC"
    )

    age = (
        now
        - df["timestamp"]
    ).dt.total_seconds()

    return df[
        age
        <= ACTIVE_ALERT_WINDOW_SECONDS
    ]


# ==========================================================
# ESTADO DEL SISTEMA
# ==========================================================

def get_system_status(
    active_df
):

    if active_df.empty:

        return (
            "NORMAL",
            (
                "No se han detectado alertas "
                "de seguridad activas."
            )
        )

    max_rank = (
        active_df["severity"]
        .apply(severity_rank)
        .max()
    )

    if max_rank >= 4:

        return (
            "CRITICAL",
            "Incidente crítico detectado."
        )

    if max_rank == 3:

        return (
            "WARNING",
            (
                "Se han detectado alertas "
                "de severidad alta."
            )
        )

    if max_rank == 2:

        return (
            "WARNING",
            (
                "Se han detectado alertas "
                "de severidad media."
            )
        )

    return (
        "NORMAL",
        (
            "No existen alertas de "
            "seguridad relevantes."
        )
    )


# ==========================================================
# GENERACIÓN DE INFORMES
# ==========================================================

def generate_report():

    result = subprocess.run(
        [
            "python3",
            "ids/report_generator.py"
        ],
        capture_output=True,
        text=True
    )

    return (
        result.stdout,
        result.stderr
    )


# ==========================================================
# DATOS
# ==========================================================

df = load_events()

active_df = get_active_events(
    df
)

status, status_msg = (
    get_system_status(
        active_df
    )
)


# ==========================================================
# RESUMEN GENERAL
# ==========================================================

col1, col2, col3, col4, col5 = st.columns(
    5
)

col1.metric(
    "Estado",
    status
)

col2.metric(
    "Alertas activas",
    len(active_df)
)

col3.metric(
    "Eventos históricos",
    len(df)
)

col4.metric(
    "Alertas críticas",
    (
        int(
            (
                df["severity"]
                == "CRITICAL"
            ).sum()
        )
        if not df.empty
        else 0
    )
)

col5.metric(
    "Fuentes detectadas",
    (
        df["source_ip"].nunique()
        if not df.empty
        else 0
    )
)


# ==========================================================
# ESTADO OPERACIONAL
# ==========================================================

if status == "CRITICAL":

    st.error(
        f"🔴 {status_msg}"
    )

elif status == "WARNING":

    st.warning(
        f"🟠 {status_msg}"
    )

else:

    st.success(
        f"🟢 {status_msg}"
    )


st.caption(
    "Una alerta se considera activa durante "
    f"{ACTIVE_ALERT_WINDOW_SECONDS} segundos. "
    "Los eventos permanecen disponibles en el histórico."
)


st.divider()


# ==========================================================
# ALERTAS ACTIVAS
# ==========================================================

st.subheader(
    "🚨 Alertas activas"
)

if active_df.empty:

    st.success(
        "No existen incidentes activos."
    )

else:

    st.dataframe(
        active_df[
            [
                "timestamp",
                "severity",
                "alert_type",
                "source_ip",
                "message"
            ]
        ],
        use_container_width=True,
        height=220
    )


st.divider()


# ==========================================================
# HISTÓRICO Y ÚLTIMO EVENTO
# ==========================================================

left, right = st.columns(
    [2, 1]
)


with left:

    st.subheader(
        "📋 Histórico de eventos"
    )

    if df.empty:

        st.info(
            "Todavía no se han registrado "
            "eventos de seguridad."
        )

    else:

        st.dataframe(
            df[
                [
                    "timestamp",
                    "severity",
                    "alert_type",
                    "source_ip",
                    "message",
                    "raw_sentence"
                ]
            ],
            use_container_width=True,
            height=360
        )


with right:

    st.subheader(
        "🔎 Último evento"
    )

    if df.empty:

        st.write(
            "Sin eventos registrados."
        )

    else:

        last = df.iloc[0]

        st.write(
            f"**Severidad:** "
            f"{last['severity']}"
        )

        st.write(
            f"**Tipo:** "
            f"{last['alert_type']}"
        )

        st.write(
            f"**Origen:** "
            f"`{last['source_ip']}`"
        )

        st.write(
            f"**Mensaje:** "
            f"{last['message']}"
        )

        st.write(
            "**Evidencia:**"
        )

        st.code(
            str(
                last["raw_sentence"]
            ),
            language="text"
        )


st.divider()


# ==========================================================
# ANALÍTICA
# ==========================================================

st.subheader(
    "📊 Analítica de incidentes"
)


if df.empty:

    st.info(
        "Las gráficas estarán disponibles "
        "cuando se registre el primer evento."
    )

else:

    col_a, col_b = st.columns(
        2
    )


    with col_a:

        st.write(
            "**Eventos por severidad**"
        )

        severity_chart = (
            alt.Chart(df)
            .mark_bar()
            .encode(
                x=alt.X(
                    "severity:N",
                    title="Severidad"
                ),
                y=alt.Y(
                    "count():Q",
                    title="Número de eventos"
                ),
                tooltip=[
                    "severity:N",
                    "count():Q"
                ]
            )
            .properties(
                height=300
            )
        )

        st.altair_chart(
            severity_chart,
            use_container_width=True
        )


    with col_b:

        st.write(
            "**Eventos por tipo**"
        )

        type_chart = (
            alt.Chart(df)
            .mark_bar()
            .encode(
                x=alt.X(
                    "count():Q",
                    title="Número de eventos"
                ),
                y=alt.Y(
                    "alert_type:N",
                    title="Tipo de alerta",
                    sort="-x"
                ),
                tooltip=[
                    "alert_type:N",
                    "count():Q"
                ]
            )
            .properties(
                height=300
            )
        )

        st.altair_chart(
            type_chart,
            use_container_width=True
        )


st.divider()


# ==========================================================
# INFORMES
# ==========================================================

st.subheader(
    "📄 Informes de incidentes"
)


if st.button(
    "Generar informe de incidente"
):

    if df.empty:

        st.warning(
            "No existen eventos con los que "
            "generar un informe."
        )

    else:

        stdout, stderr = (
            generate_report()
        )

        if stderr:

            st.error(
                stderr
            )

        else:

            st.success(
                "Informe generado correctamente."
            )

            st.code(
                stdout,
                language="text"
            )


# ==========================================================
# INFORMES EXISTENTES
# ==========================================================

if REPORTS_DIR.exists():

    reports = sorted(
        REPORTS_DIR.glob(
            "incident_report_*"
        ),
        reverse=True
    )

else:

    reports = []


if reports:

    st.write(
        "**Últimos informes generados:**"
    )

    for report in reports[:6]:

        st.write(
            f"- `{report}`"
        )


# ==========================================================
# PIE
# ==========================================================

st.divider()

st.caption(
    "PHASMIDA · Maritime OT Security Laboratory"
)
