#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import csv
import json
import math
import os
import socket
import time
import tkinter as tk
from datetime import datetime
from pathlib import Path


# ============================================================
# CONFIGURACIÓN PHASMIDA
# ============================================================

BASE_DIR = Path(__file__).resolve().parent.parent
STATE_FILE = BASE_DIR / "events" / "nmea_state.json"

UPDATE_INTERVAL_MS = 500
COMMUNICATION_TIMEOUT = 5.0

# Canal de control legítimo SCADA -> engine_node
ENGINE_CONTROL_HOST = os.getenv("PHASMIDA_ENGINE_HOST", "127.0.0.1")
ENGINE_CONTROL_PORT = int(os.getenv("PHASMIDA_CONTROL_PORT", "10130"))
CONTROL_TIMEOUT = 1.0


# ============================================================
# ESTADOS
# ============================================================

NORMAL = "NORMAL"
ALERTA = "ALERTA"
FALLO = "FALLO"
PARADO = "PARADO"

ABIERTA = "ABIERTA"
CERRADA = "CERRADA"

DESCONOCIDO = "DESCONOCIDO"


# ============================================================
# COLORES SCADA
# ============================================================

NEGRO = "#000000"

FONDO_SCADA = "#E2E2E2"
FONDO_PANEL = "#EEEEEE"
FONDO_EQUIPO = "#D0D0D0"

FONDO_BOTON = "#A7A7A7"
FONDO_BOTON_ACTIVO = "#B8B8B8"

BLANCO = "#FFFFFF"
GRIS = "#666666"
GRIS_TITULO = "#000000"
GRIS_OSCURO = "#555555"
GRIS_COMBUSTIBLE = "#969696"

VERDE = "#159447"
AMBAR = "#D49A00"
ROJO = "#D62828"

AZUL = "#2675BF"


COLORES_ESTADO = {
    NORMAL: VERDE,
    ALERTA: AMBAR,
    FALLO: ROJO,
    PARADO: GRIS,
    ABIERTA: VERDE,
    CERRADA: AMBAR,
    DESCONOCIDO: GRIS,
}


# ============================================================
# CLASE EQUIPO
# ============================================================

class Equipo:

    def __init__(self, nombre, estado=DESCONOCIDO):

        self.nombre = nombre
        self.estado = estado


# ============================================================
# ESTADO PHASMIDA
# ============================================================

class EstadoPHASMIDA:

    """
    Representación local del estado recibido desde PHASMIDA Core.

    Esta clase NO simula el proceso físico.

    Su única función es leer events/nmea_state.json y adaptar
    las variables de PHASMIDA al modelo gráfico heredado del
    SCADA desarrollado en TF-SPIC.
    """

    def __init__(self):

        # ----------------------------------------------------
        # COMUNICACIÓN
        # ----------------------------------------------------

        self.online = False
        self.last_update = None
        self.last_file_mtime = None

        self.source_ip = None
        self.last_sentence = None
        self.last_sentence_type = None
        self.last_talker_id = None

        # ----------------------------------------------------
        # PROPULSIÓN
        # ----------------------------------------------------

        self.motor_babor = Equipo(
            "Motor babor"
        )

        self.motor_estribor = Equipo(
            "Motor estribor"
        )

        self.rpm_babor = 0.0
        self.rpm_estribor = 0.0

        self.temp_babor = None
        self.temp_estribor = None

        self.presion_aceite_babor = None
        self.presion_aceite_estribor = None

        self.coolant_babor = None
        self.coolant_estribor = None

        self.potencia_babor = None
        self.potencia_estribor = None

        # ----------------------------------------------------
        # COMBUSTIBLE
        # ----------------------------------------------------

        self.bomba_comb_babor = Equipo(
            "Bomba combustible babor"
        )

        self.bomba_comb_estribor = Equipo(
            "Bomba combustible estribor"
        )

        self.valvula_comb_babor = Equipo(
            "Válvula combustible babor"
        )

        self.valvula_comb_estribor = Equipo(
            "Válvula combustible estribor"
        )

        # PHASMIDA dispone actualmente de un depósito común.
        self.nivel_combustible = None

        self.presion_combustible = None
        self.caudal_combustible = None

        # ----------------------------------------------------
        # REFRIGERACIÓN
        # ----------------------------------------------------

        self.bomba_ref_1 = Equipo(
            "Bomba refrigeración 1"
        )

        self.bomba_ref_2 = Equipo(
            "Bomba refrigeración 2"
        )

        self.caudal_refrigeracion = None
        self.presion_refrigeracion = None
        self.temp_refrigeracion = None

        # ----------------------------------------------------
        # SISTEMA ELÉCTRICO
        # ----------------------------------------------------

        self.generador = Equipo(
            "Generador"
        )

        self.tension_generador = None
        self.corriente_generador = None
        self.frecuencia_generador = None
        self.potencia_generador = None

        # ----------------------------------------------------
        # SEGURIDAD
        # ----------------------------------------------------

        self.security_suspicious = False
        self.security_alerts = []

        # ----------------------------------------------------
        # HISTÓRICO LOCAL DEL SCADA
        # ----------------------------------------------------

        self.historial = []

        self._ultimo_registro = 0.0

    # ========================================================
    # UTILIDADES
    # ========================================================

    @staticmethod
    def bool_equipo(
        value,
        activo=NORMAL,
        inactivo=PARADO
    ):

        if value is True:
            return activo

        if value is False:
            return inactivo

        return DESCONOCIDO

    @staticmethod
    def bool_valvula(value):

        if value is True:
            return ABIERTA

        if value is False:
            return CERRADA

        return DESCONOCIDO

    @staticmethod
    def numero(value, default=None):

        if value is None:
            return default

        try:
            return float(value)

        except (TypeError, ValueError):
            return default

    # ========================================================
    # LECTURA DEL ESTADO
    # ========================================================

    def actualizar(self):

        if not STATE_FILE.exists():

            self.online = False
            return False

        try:

            mtime = STATE_FILE.stat().st_mtime

            with STATE_FILE.open(
                "r",
                encoding="utf-8"
            ) as archivo:

                data = json.load(
                    archivo
                )

        except (
            OSError,
            json.JSONDecodeError
        ):

            self.online = False
            return False

        # ----------------------------------------------------
        # METADATOS
        # ----------------------------------------------------

        self.last_file_mtime = mtime

        self.source_ip = data.get(
            "source_ip"
        )

        self.last_sentence = data.get(
            "last_sentence"
        )

        self.last_sentence_type = data.get(
            "last_sentence_type"
        )

        self.last_talker_id = data.get(
            "last_talker_id"
        )

        updated_at = data.get(
            "updated_at"
        )

        self.last_update = updated_at

        # ----------------------------------------------------
        # ESTADO DE COMUNICACIÓN
        # ----------------------------------------------------

        age = time.time() - mtime

        self.online = (
            age <= COMMUNICATION_TIMEOUT
        )

        # ----------------------------------------------------
        # PROPULSIÓN
        # ----------------------------------------------------

        propulsion = data.get(
            "propulsion",
            {}
        )

        port = propulsion.get(
            "port",
            {}
        )

        starboard = propulsion.get(
            "starboard",
            {}
        )

        port_running = port.get(
            "running"
        )

        starboard_running = starboard.get(
            "running"
        )

        self.motor_babor.estado = (
            self.bool_equipo(
                port_running
            )
        )

        self.motor_estribor.estado = (
            self.bool_equipo(
                starboard_running
            )
        )

        self.rpm_babor = (
            self.numero(
                port.get("rpm"),
                0.0
            )
        )

        self.rpm_estribor = (
            self.numero(
                starboard.get("rpm"),
                0.0
            )
        )

        self.temp_babor = self.numero(
            port.get(
                "temperature_c"
            )
        )

        self.temp_estribor = self.numero(
            starboard.get(
                "temperature_c"
            )
        )

        self.presion_aceite_babor = (
            self.numero(
                port.get(
                    "oil_pressure_bar"
                )
            )
        )

        self.presion_aceite_estribor = (
            self.numero(
                starboard.get(
                    "oil_pressure_bar"
                )
            )
        )

        self.coolant_babor = self.numero(
            port.get(
                "coolant_temperature_c"
            )
        )

        self.coolant_estribor = self.numero(
            starboard.get(
                "coolant_temperature_c"
            )
        )

        self.potencia_babor = self.numero(
            port.get(
                "power_kw"
            )
        )

        self.potencia_estribor = self.numero(
            starboard.get(
                "power_kw"
            )
        )

        # ----------------------------------------------------
        # COMBUSTIBLE
        # ----------------------------------------------------

        fuel = data.get(
            "fuel",
            {}
        )

        self.bomba_comb_babor.estado = (
            self.bool_equipo(
                fuel.get(
                    "port_pump"
                )
            )
        )

        self.bomba_comb_estribor.estado = (
            self.bool_equipo(
                fuel.get(
                    "starboard_pump"
                )
            )
        )

        self.valvula_comb_babor.estado = (
            self.bool_valvula(
                fuel.get(
                    "port_valve"
                )
            )
        )

        self.valvula_comb_estribor.estado = (
            self.bool_valvula(
                fuel.get(
                    "starboard_valve"
                )
            )
        )

        self.nivel_combustible = (
            self.numero(
                fuel.get(
                    "tank_level_percent"
                )
            )
        )

        self.presion_combustible = (
            self.numero(
                fuel.get(
                    "pressure_bar"
                )
            )
        )

        self.caudal_combustible = (
            self.numero(
                fuel.get(
                    "flow_l_min"
                )
            )
        )

        # ----------------------------------------------------
        # REFRIGERACIÓN
        # ----------------------------------------------------

        cooling = data.get(
            "cooling",
            {}
        )

        self.bomba_ref_1.estado = (
            self.bool_equipo(
                cooling.get(
                    "port_pump"
                )
            )
        )

        self.bomba_ref_2.estado = (
            self.bool_equipo(
                cooling.get(
                    "starboard_pump"
                )
            )
        )

        self.caudal_refrigeracion = (
            self.numero(
                cooling.get(
                    "flow_l_min"
                )
            )
        )

        self.presion_refrigeracion = (
            self.numero(
                cooling.get(
                    "pressure_bar"
                )
            )
        )

        self.temp_refrigeracion = (
            self.numero(
                cooling.get(
                    "temperature_c"
                )
            )
        )

        # ----------------------------------------------------
        # SISTEMA ELÉCTRICO
        # ----------------------------------------------------

        electrical = data.get(
            "electrical",
            {}
        )

        self.generador.estado = (
            self.bool_equipo(
                electrical.get(
                    "generator_running"
                )
            )
        )

        self.tension_generador = (
            self.numero(
                electrical.get(
                    "voltage_v"
                )
            )
        )

        self.corriente_generador = (
            self.numero(
                electrical.get(
                    "current_a"
                )
            )
        )

        self.frecuencia_generador = (
            self.numero(
                electrical.get(
                    "frequency_hz"
                )
            )
        )

        self.potencia_generador = (
            self.numero(
                electrical.get(
                    "power_kw"
                )
            )
        )

        # ----------------------------------------------------
        # SEGURIDAD
        # ----------------------------------------------------

        security = data.get(
            "security",
            {}
        )

        self.security_suspicious = bool(
            security.get(
                "suspicious",
                False
            )
        )

        alerts = security.get(
            "alerts",
            []
        )

        if isinstance(alerts, list):
            self.security_alerts = alerts
        else:
            self.security_alerts = []

        # ----------------------------------------------------
        # HISTÓRICO LOCAL
        # ----------------------------------------------------

        ahora = time.time()

        if (
            ahora
            -
            self._ultimo_registro
            >=
            1.0
        ):

            self.registrar_historial()

            self._ultimo_registro = ahora

        return True

    # ========================================================
    # HISTÓRICO
    # ========================================================

    def registrar_historial(self):

        self.historial.append(
            {
                "timestamp":
                    datetime.now().isoformat(),

                "rpm_babor":
                    self.rpm_babor,

                "temperatura_babor":
                    self.temp_babor,

                "aceite_babor":
                    self.presion_aceite_babor,

                "coolant_babor":
                    self.coolant_babor,

                "potencia_babor_kw":
                    self.potencia_babor,

                "rpm_estribor":
                    self.rpm_estribor,

                "temperatura_estribor":
                    self.temp_estribor,

                "aceite_estribor":
                    self.presion_aceite_estribor,

                "coolant_estribor":
                    self.coolant_estribor,

                "potencia_estribor_kw":
                    self.potencia_estribor,

                "nivel_combustible":
                    self.nivel_combustible,

                "presion_combustible":
                    self.presion_combustible,

                "caudal_combustible":
                    self.caudal_combustible,

                "presion_refrigeracion":
                    self.presion_refrigeracion,

                "caudal_refrigeracion":
                    self.caudal_refrigeracion,

                "temperatura_refrigeracion":
                    self.temp_refrigeracion,

                "tension_generador":
                    self.tension_generador,

                "corriente_generador":
                    self.corriente_generador,

                "frecuencia_generador":
                    self.frecuencia_generador,

                "potencia_generador":
                    self.potencia_generador,

                "security_suspicious":
                    self.security_suspicious,
            }
        )

        # Evitamos crecimiento ilimitado en ejecución larga.
        if len(self.historial) > 10000:
            self.historial = (
                self.historial[-10000:]
            )

    # ========================================================
    # CSV
    # ========================================================

    def exportar_csv(self):

        if not self.historial:
            return None

        reports_dir = (
            BASE_DIR
            /
            "reports"
        )

        reports_dir.mkdir(
            exist_ok=True
        )

        nombre = (
            reports_dir
            /
            (
                "scada_phasmida_"
                +
                datetime.now().strftime(
                    "%Y%m%d_%H%M%S"
                )
                +
                ".csv"
            )
        )

        with nombre.open(
            "w",
            newline="",
            encoding="utf-8"
        ) as archivo:

            writer = csv.DictWriter(
                archivo,
                fieldnames=
                    self.historial[0].keys()
            )

            writer.writeheader()

            writer.writerows(
                self.historial
            )

        return nombre


# ============================================================
# INTERFAZ SCADA
# ============================================================

class SCADA:

    def __init__(
        self,
        root
    ):

        self.root = root

        self.root.title(
            "PHASMIDA - Cámara de Máquinas"
        )

        self.root.geometry(
            "1480x900"
        )

        self.root.configure(
            bg=FONDO_SCADA
        )

        self.sim = EstadoPHASMIDA()

        self.angulo_helice_bb = 0
        self.angulo_helice_er = 0

        self.export_msg = ""
        self.control_msg = ""

        # Estado visual de fallo de los motores.
        # Al ordenar un fallo desde el SCADA se muestra primero PARADO
        # y, tras un breve retardo, FALLO hasta ejecutar RESET.
        self.fallo_motor_bb = False
        self.fallo_motor_er = False
        self.fallo_motor_bb_after_id = None
        self.fallo_motor_er_after_id = None
        self.FALLO_MOTOR_DELAY_MS = 1000

        # ----------------------------------------------------
        # LOGO CORPORATIVO UNED | ETSI
        # ----------------------------------------------------

        self.logo_uned = None

        try:

            ruta_script = os.path.dirname(
                os.path.abspath(__file__)
            )

            posibles_logos = [
                os.path.join(
                    ruta_script,
                    "logoUNED.png"
                ),
                os.path.join(
                    os.path.dirname(
                        ruta_script
                    ),
                    "logoUNED.png"
                ),
            ]

            ruta_logo = next(
                (
                    ruta
                    for ruta in posibles_logos
                    if os.path.exists(ruta)
                ),
                None
            )

            if ruta_logo:

                logo_original = tk.PhotoImage(
                    file=ruta_logo
                )

                self.logo_uned = (
                    logo_original.subsample(
                        4,
                        4
                    )
                )

        except Exception as error:

            print(
                "No se pudo cargar el logo UNED:",
                error
            )

        # ----------------------------------------------------
        # LOGO PHASMIDA
        # ----------------------------------------------------

        self.logo_phasmida = None

        try:

            ruta_script = os.path.dirname(
                os.path.abspath(__file__)
            )

            posibles_logos_phasmida = [
                os.path.join(ruta_script, "logo_phasmida.png"),
                os.path.join(ruta_script, "logoPHASMIDA.png"),
                os.path.join(ruta_script, "phasmida_logo.png"),
                os.path.join(os.path.dirname(ruta_script), "logo_phasmida.png"),
                os.path.join(os.path.dirname(ruta_script), "logoPHASMIDA.png"),
                os.path.join(os.path.dirname(ruta_script), "phasmida_logo.png"),
            ]

            ruta_logo_phasmida = next(
                (
                    ruta
                    for ruta in posibles_logos_phasmida
                    if os.path.exists(ruta)
                ),
                None
            )

            if ruta_logo_phasmida:

                logo_original_phasmida = tk.PhotoImage(
                    file=ruta_logo_phasmida
                )

                # Ajuste aproximado para cabecera.
                factor = max(
                    1,
                    math.ceil(logo_original_phasmida.width() / 250),
                    math.ceil(logo_original_phasmida.height() / 80)
                )

                self.logo_phasmida = logo_original_phasmida.subsample(
                    factor,
                    factor
                )

        except Exception as error:

            print(
                "No se pudo cargar el logo PHASMIDA:",
                error
            )

        # ----------------------------------------------------
        # CANVAS PRINCIPAL
        # ----------------------------------------------------

        self.canvas = tk.Canvas(
            root,
            width=1480,
            height=800,
            bg=FONDO_SCADA,
            highlightthickness=0
        )

        self.canvas.pack()

        # ----------------------------------------------------
        # CONTROLES DEL PROCESO
        # ----------------------------------------------------
        #
        # Los botones no modifican directamente nmea_state.json.
        # Cada acción se envía por UDP al engine_node. El cambio
        # se aplica en el proceso físico simulado y vuelve al SCADA
        # a través de la telemetría normal y PHASMIDA Core.
        # ----------------------------------------------------

        controls = tk.Frame(
            root,
            bg=FONDO_SCADA
        )

        controls.pack(
            pady=4
        )

        botones = [
            ("Bomba combustible BB", "FUEL_PORT_PUMP"),
            ("Válvula combustible BB", "FUEL_PORT_VALVE"),
            ("Bomba combustible ER", "FUEL_STBD_PUMP"),
            ("Válvula combustible ER", "FUEL_STBD_VALVE"),
            ("Bomba refrigeración 1", "COOL_PORT_PUMP"),
            ("Bomba refrigeración 2", "COOL_STBD_PUMP"),
            ("Fallo motor BB", "ENGINE_PORT"),
            ("Fallo motor ER", "ENGINE_STBD"),
        ]

        self.botones_control = {}

        for i, (texto, target) in enumerate(botones):

            boton = tk.Button(
                controls,
                text=texto,
                command=lambda t=target: self.enviar_control(
                    "TOGGLE",
                    t
                ),
                bg=FONDO_BOTON,
                fg=NEGRO,
                activebackground=FONDO_BOTON_ACTIVO,
                activeforeground=NEGRO,
                relief="solid",
                bd=1,
                padx=8,
                pady=4
            )

            boton.grid(
                row=0,
                column=i,
                padx=2
            )

            self.botones_control[target] = boton

        tk.Button(
            controls,
            text="Reset sistema",
            command=lambda: self.enviar_control(
                "RESET",
                "SYSTEM"
            ),
            bg=FONDO_BOTON,
            fg=NEGRO,
            activebackground=FONDO_BOTON_ACTIVO,
            activeforeground=NEGRO,
            relief="solid",
            bd=1,
            padx=8,
            pady=4
        ).grid(
            row=0,
            column=len(botones),
            padx=2
        )

        tk.Button(
            controls,
            text="Exportar CSV",
            command=self.export_csv,
            bg=FONDO_BOTON,
            fg=NEGRO,
            activebackground=FONDO_BOTON_ACTIVO,
            activeforeground=NEGRO,
            relief="solid",
            bd=1,
            padx=8,
            pady=4
        ).grid(
            row=0,
            column=len(botones) + 1,
            padx=2
        )

        self.actualizar()

    # ========================================================
    # CONTROLES GUI
    # ========================================================

    def activar_fallo_motor(self, target):
        """Activa el estado visual FALLO tras mostrar primero PARADO."""

        if target == "ENGINE_PORT":
            self.fallo_motor_bb_after_id = None

            if self.sim.motor_babor.estado == PARADO:
                self.fallo_motor_bb = True

        elif target == "ENGINE_STBD":
            self.fallo_motor_er_after_id = None

            if self.sim.motor_estribor.estado == PARADO:
                self.fallo_motor_er = True

    def programar_fallo_motor(self, target):
        """Programa la transición visual PARADO -> FALLO."""

        if target == "ENGINE_PORT":
            if self.fallo_motor_bb_after_id is not None:
                self.root.after_cancel(self.fallo_motor_bb_after_id)

            self.fallo_motor_bb = False
            self.fallo_motor_bb_after_id = self.root.after(
                self.FALLO_MOTOR_DELAY_MS,
                lambda: self.activar_fallo_motor("ENGINE_PORT")
            )

        elif target == "ENGINE_STBD":
            if self.fallo_motor_er_after_id is not None:
                self.root.after_cancel(self.fallo_motor_er_after_id)

            self.fallo_motor_er = False
            self.fallo_motor_er_after_id = self.root.after(
                self.FALLO_MOTOR_DELAY_MS,
                lambda: self.activar_fallo_motor("ENGINE_STBD")
            )

    def resetear_fallos_visuales(self):
        """Elimina los estados visuales de fallo al ejecutar RESET."""

        if self.fallo_motor_bb_after_id is not None:
            self.root.after_cancel(self.fallo_motor_bb_after_id)
            self.fallo_motor_bb_after_id = None

        if self.fallo_motor_er_after_id is not None:
            self.root.after_cancel(self.fallo_motor_er_after_id)
            self.fallo_motor_er_after_id = None

        self.fallo_motor_bb = False
        self.fallo_motor_er = False

    def enviar_control(
        self,
        command,
        target
    ):
        """
        Envía una orden de operador al engine_node mediante UDP.

        El SCADA no modifica directamente el estado compartido.
        La actuación se aplica en el simulador físico y el nuevo
        estado regresa posteriormente mediante PHASMIDA Core.
        """

        message = {
            "source": "scada_phasmida",
            "command": command,
            "target": target,
            "timestamp": datetime.now().astimezone().isoformat()
        }

        control_socket = socket.socket(
            socket.AF_INET,
            socket.SOCK_DGRAM
        )

        control_socket.settimeout(
            CONTROL_TIMEOUT
        )

        try:

            control_socket.sendto(
                json.dumps(message).encode("utf-8"),
                (ENGINE_CONTROL_HOST, ENGINE_CONTROL_PORT)
            )

            raw_response, _ = control_socket.recvfrom(4096)

            response = json.loads(
                raw_response.decode("utf-8")
            )

            if response.get("success"):

                if command == "RESET":
                    self.resetear_fallos_visuales()

                    self.control_msg = (
                        "Orden aceptada: RESET DEL SISTEMA"
                    )

                else:
                    value = response.get("value")

                    if target in ("ENGINE_PORT", "ENGINE_STBD"):
                        if value is False:
                            self.programar_fallo_motor(target)
                        elif value is True:
                            if target == "ENGINE_PORT":
                                self.fallo_motor_bb = False
                            else:
                                self.fallo_motor_er = False

                    estado = "ACTIVO" if value is True else "INACTIVO"
                    self.control_msg = (
                        f"Orden aceptada: {target} -> {estado}"
                    )

                print(
                    "[SCADA CONTROL]",
                    self.control_msg
                )

            else:
                error = response.get(
                    "error",
                    "ERROR DESCONOCIDO"
                )
                self.control_msg = f"Orden rechazada: {error}"
                print(
                    "[SCADA CONTROL ERROR]",
                    self.control_msg
                )

        except socket.timeout:
            self.control_msg = (
                "Sin respuesta de engine_node "
                f"({ENGINE_CONTROL_HOST}:{ENGINE_CONTROL_PORT})"
            )
            print(
                "[SCADA CONTROL ERROR]",
                self.control_msg
            )

        except (OSError, json.JSONDecodeError) as error:
            self.control_msg = f"Error de control: {error}"
            print(
                "[SCADA CONTROL ERROR]",
                self.control_msg
            )

        finally:
            control_socket.close()

    def export_csv(self):

        nombre = (
            self.sim.exportar_csv()
        )

        if nombre:

            self.export_msg = (
                f"CSV exportado: "
                f"{nombre.name}"
            )

        else:

            self.export_msg = (
                "No existen datos para exportar"
            )

    # ========================================================
    # FORMATO
    # ========================================================

    @staticmethod
    def fmt(
        value,
        decimals=1,
        suffix=""
    ):

        if value is None:
            return "--"

        try:

            return (
                f"{float(value):.{decimals}f}"
                f"{suffix}"
            )

        except (
            TypeError,
            ValueError
        ):

            return "--"

    # ========================================================
    # UTILIDADES GRÁFICAS
    # ========================================================

    def color_estado(
        self,
        equipo
    ):

        return COLORES_ESTADO.get(
            equipo.estado,
            GRIS
        )

    def color_propulsion(
        self,
        motor,
        rpm
    ):

        if not self.sim.online:
            return GRIS

        if (
            motor.estado == FALLO
            or
            (motor is self.sim.motor_babor and self.fallo_motor_bb)
            or
            (motor is self.sim.motor_estribor and self.fallo_motor_er)
        ):
            return ROJO

        if (
            motor.estado == NORMAL
            and
            rpm is not None
            and
            rpm > 50
        ):
            return VERDE

        return GRIS_COMBUSTIBLE

    def titulo_seccion(
        self,
        x,
        y,
        texto
    ):

        self.canvas.create_text(
            x,
            y,
            text=texto,
            fill=GRIS_TITULO,
            anchor="w",
            font=(
                "Helvetica",
                10,
                "bold"
            )
        )

    # ========================================================
    # DEPÓSITO
    # ========================================================

    def dibujar_deposito(
        self,
        x,
        y,
        nivel,
        nombre
    ):

        ancho = 90
        alto = 105

        nivel_grafico = (
            nivel
            if nivel is not None
            else 0.0
        )

        nivel_grafico = max(
            0.0,
            min(
                100.0,
                nivel_grafico
            )
        )

        self.canvas.create_text(
            x + ancho / 2,
            y - 16,
            text=nombre,
            fill=NEGRO,
            font=(
                "Helvetica",
                9,
                "bold"
            )
        )

        self.canvas.create_rectangle(
            x,
            y,
            x + ancho,
            y + alto,
            outline=NEGRO,
            width=2
        )

        altura_liquido = (
            (alto - 6)
            *
            nivel_grafico
            /
            100
        )

        self.canvas.create_rectangle(
            x + 3,
            y + alto - 3 - altura_liquido,
            x + ancho - 3,
            y + alto - 3,
            fill=GRIS_COMBUSTIBLE,
            outline=""
        )

        texto_nivel = (
            self.fmt(
                nivel,
                1,
                " %"
            )
        )

        self.canvas.create_text(
            x + ancho / 2,
            y + alto + 16,
            text=texto_nivel,
            fill=NEGRO,
            font=(
                "Helvetica",
                9
            )
        )

    # ========================================================
    # TUBERÍA
    # ========================================================

    def tuberia(
        self,
        x1,
        y1,
        x2,
        y2,
        color
    ):

        self.canvas.create_line(
            x1,
            y1,
            x2,
            y2,
            fill=color,
            width=4
        )

    # ========================================================
    # VÁLVULA
    # ========================================================

    def dibujar_valvula(
        self,
        x,
        y,
        equipo,
        nombre="Válvula"
    ):

        color = (
            self.color_estado(
                equipo
            )
        )

        self.canvas.create_text(
            x,
            y - 24,
            text=nombre,
            fill=NEGRO,
            font=(
                "Helvetica",
                9
            )
        )

        self.canvas.create_polygon(
            x - 25,
            y - 15,
            x,
            y,
            x - 25,
            y + 15,
            fill=FONDO_SCADA,
            outline=color,
            width=2
        )

        self.canvas.create_polygon(
            x + 25,
            y - 15,
            x,
            y,
            x + 25,
            y + 15,
            fill=FONDO_SCADA,
            outline=color,
            width=2
        )

        self.canvas.create_text(
            x,
            y + 30,
            text=equipo.estado,
            fill=color,
            font=(
                "Helvetica",
                8,
                "bold"
            )
        )

    # ========================================================
    # BOMBA
    # ========================================================

    def dibujar_bomba(
        self,
        x,
        y,
        equipo,
        nombre="Bomba"
    ):

        color = (
            self.color_estado(
                equipo
            )
        )

        self.canvas.create_text(
            x,
            y - 43,
            text=nombre,
            fill=NEGRO,
            font=(
                "Helvetica",
                9
            )
        )

        self.canvas.create_oval(
            x - 30,
            y - 30,
            x + 30,
            y + 30,
            fill=FONDO_SCADA,
            outline=color,
            width=2
        )

        self.canvas.create_line(
            x,
            y,
            x,
            y - 23,
            fill=NEGRO,
            width=2
        )

        self.canvas.create_line(
            x,
            y,
            x + 20,
            y + 12,
            fill=NEGRO,
            width=2
        )

        self.canvas.create_line(
            x,
            y,
            x - 20,
            y + 12,
            fill=NEGRO,
            width=2
        )

        self.canvas.create_text(
            x,
            y + 44,
            text=equipo.estado,
            fill=color,
            font=(
                "Helvetica",
                8,
                "bold"
            )
        )

    # ========================================================
    # MOTOR
    # ========================================================

    def dibujar_motor(
        self,
        x,
        y,
        nombre,
        equipo,
        rpm,
        temperatura,
        presion_aceite,
        coolant
    ):

        estado_visual = equipo.estado

        if nombre == "Motor babor" and self.fallo_motor_bb:
            estado_visual = FALLO

        elif nombre == "Motor estribor" and self.fallo_motor_er:
            estado_visual = FALLO

        color = COLORES_ESTADO.get(
            estado_visual,
            GRIS
        )

        ancho = 250
        alto = 145

        self.canvas.create_rectangle(
            x,
            y,
            x + ancho,
            y + alto,
            fill=FONDO_EQUIPO,
            outline=color,
            width=2
        )

        self.canvas.create_text(
            x + ancho / 2,
            y + 18,
            text=nombre,
            fill=NEGRO,
            font=(
                "Helvetica",
                11,
                "bold"
            )
        )

        for i in range(5):

            cx = (
                x
                +
                22
                +
                i * 27
            )

            self.canvas.create_rectangle(
                cx,
                y + 45,
                cx + 18,
                y + 78,
                fill="#8F8F8F",
                outline=NEGRO
            )

        self.canvas.create_line(
            x + 20,
            y + 97,
            x + 145,
            y + 97,
            fill=NEGRO,
            width=5
        )

        self.canvas.create_text(
            x + 165,
            y + 42,
            text="RPM",
            fill=NEGRO,
            anchor="w",
            font=(
                "Helvetica",
                8
            )
        )

        rpm_text = (
            "--"
            if rpm is None
            else str(
                int(
                    round(rpm)
                )
            )
        )

        self.canvas.create_text(
            x + 165,
            y + 58,
            text=rpm_text,
            fill=NEGRO,
            anchor="w",
            font=(
                "Helvetica",
                11,
                "bold"
            )
        )

        self.canvas.create_text(
            x + 165,
            y + 76,
            text="Temperatura",
            fill=NEGRO,
            anchor="w",
            font=(
                "Helvetica",
                8
            )
        )

        self.canvas.create_text(
            x + 165,
            y + 91,
            text=self.fmt(
                temperatura,
                1,
                " °C"
            ),
            fill=NEGRO,
            anchor="w",
            font=(
                "Helvetica",
                9
            )
        )

        self.canvas.create_text(
            x + 165,
            y + 108,
            text=(
                "Aceite: "
                +
                self.fmt(
                    presion_aceite,
                    2,
                    " bar"
                )
            ),
            fill=NEGRO,
            anchor="w",
            font=(
                "Helvetica",
                8
            )
        )

        self.canvas.create_text(
            x + 165,
            y + 124,
            text=(
                "Coolant: "
                +
                self.fmt(
                    coolant,
                    1,
                    " °C"
                )
            ),
            fill=NEGRO,
            anchor="w",
            font=(
                "Helvetica",
                8
            )
        )

        self.canvas.create_oval(
            x + 18,
            y + 118,
            x + 30,
            y + 130,
            fill=color,
            outline=""
        )

        self.canvas.create_text(
            x + 38,
            y + 124,
            text=estado_visual,
            fill=color,
            anchor="w",
            font=(
                "Helvetica",
                9,
                "bold"
            )
        )

    # ========================================================
    # HÉLICE
    # ========================================================

    def dibujar_helice(
        self,
        x,
        y,
        rpm,
        nombre,
        angulo,
        color_propulsion
    ):

        self.canvas.create_text(
            x,
            y - 55,
            text=nombre,
            fill=NEGRO,
            font=(
                "Helvetica",
                9
            )
        )

        radio = 38

        for i in range(4):

            a = math.radians(
                angulo
                +
                i * 90
            )

            ex = (
                x
                +
                math.cos(a)
                *
                radio
            )

            ey = (
                y
                +
                math.sin(a)
                *
                radio
            )

            self.canvas.create_line(
                x,
                y,
                ex,
                ey,
                fill=color_propulsion,
                width=7,
                capstyle=tk.ROUND
            )

        self.canvas.create_oval(
            x - 8,
            y - 8,
            x + 8,
            y + 8,
            fill=color_propulsion,
            outline=""
        )

        rpm_text = (
            "-- RPM"
            if rpm is None
            else
            f"{int(round(rpm))} RPM"
        )

        self.canvas.create_text(
            x,
            y + 55,
            text=rpm_text,
            fill=color_propulsion,
            font=(
                "Helvetica",
                9,
                "bold"
            )
        )

    # ========================================================
    # EVENTOS
    # ========================================================

    def panel_eventos(self):

        x1 = 1040
        y1 = 110
        x2 = 1450
        y2 = 530

        self.canvas.create_rectangle(
            x1,
            y1,
            x2,
            y2,
            fill=FONDO_PANEL,
            outline=NEGRO,
            width=1
        )

        self.canvas.create_text(
            x1 + 14,
            y1 + 20,
            text="EVENTOS / ALARMAS",
            fill=NEGRO,
            anchor="w",
            font=(
                "Helvetica",
                11,
                "bold"
            )
        )

        self.canvas.create_text(
            x1 + 15,
            y1 + 48,
            text="ORIGEN",
            fill=NEGRO,
            anchor="w",
            font=(
                "Helvetica",
                8,
                "bold"
            )
        )

        self.canvas.create_text(
            x1 + 125,
            y1 + 48,
            text="EVENTO",
            fill=NEGRO,
            anchor="w",
            font=(
                "Helvetica",
                8,
                "bold"
            )
        )

        self.canvas.create_text(
            x1 + 300,
            y1 + 48,
            text="ESTADO",
            fill=NEGRO,
            anchor="w",
            font=(
                "Helvetica",
                8,
                "bold"
            )
        )

        y = y1 + 75

        if not self.sim.online:

            self.canvas.create_text(
                x1 + 15,
                y,
                text="PHASMIDA Core",
                fill=NEGRO,
                anchor="w",
                font=(
                    "Helvetica",
                    9
                )
            )

            self.canvas.create_text(
                x1 + 125,
                y,
                text="Pérdida de comunicación",
                fill=ROJO,
                anchor="w",
                font=(
                    "Helvetica",
                    9,
                    "bold"
                )
            )

            self.canvas.create_text(
                x1 + 300,
                y,
                text="OFFLINE",
                fill=ROJO,
                anchor="w",
                font=(
                    "Helvetica",
                    9,
                    "bold"
                )
            )

            y += 30

        if self.sim.security_suspicious:

            self.canvas.create_text(
                x1 + 15,
                y,
                text="IDS",
                fill=NEGRO,
                anchor="w",
                font=(
                    "Helvetica",
                    9
                )
            )

            self.canvas.create_text(
                x1 + 125,
                y,
                text="Actividad sospechosa",
                fill=ROJO,
                anchor="w",
                font=(
                    "Helvetica",
                    9,
                    "bold"
                )
            )

            self.canvas.create_text(
                x1 + 300,
                y,
                text="ALERTA",
                fill=ROJO,
                anchor="w",
                font=(
                    "Helvetica",
                    9,
                    "bold"
                )
            )

            y += 30

        if (
            self.sim.online
            and
            not self.sim.security_suspicious
        ):

            self.canvas.create_text(
                x1 + 15,
                y,
                text="PHASMIDA",
                fill=NEGRO,
                anchor="w",
                font=(
                    "Helvetica",
                    9
                )
            )

            self.canvas.create_text(
                x1 + 125,
                y,
                text="Proceso supervisado",
                fill=VERDE,
                anchor="w",
                font=(
                    "Helvetica",
                    9
                )
            )

            self.canvas.create_text(
                x1 + 300,
                y,
                text="NORMAL",
                fill=VERDE,
                anchor="w",
                font=(
                    "Helvetica",
                    9,
                    "bold"
                )
            )

    # ========================================================
    # SISTEMA ELÉCTRICO
    # ========================================================

    def panel_electrico(self):

        x1 = 1040
        y1 = 550
        x2 = 1450
        y2 = 655

        self.canvas.create_rectangle(
            x1,
            y1,
            x2,
            y2,
            fill=FONDO_PANEL,
            outline=NEGRO
        )

        self.canvas.create_text(
            x1 + 14,
            y1 + 18,
            text="SISTEMA ELÉCTRICO",
            fill=NEGRO,
            anchor="w",
            font=(
                "Helvetica",
                10,
                "bold"
            )
        )

        color_gen = (
            self.color_estado(
                self.sim.generador
            )
        )

        self.canvas.create_oval(
            x1 + 20,
            y1 + 40,
            x1 + 34,
            y1 + 54,
            fill=color_gen,
            outline=""
        )

        self.canvas.create_text(
            x1 + 43,
            y1 + 47,
            text=(
                "Generador: "
                f"{self.sim.generador.estado}"
            ),
            fill=color_gen,
            anchor="w",
            font=(
                "Helvetica",
                9,
                "bold"
            )
        )

        self.canvas.create_text(
            x1 + 20,
            y1 + 72,
            text=(
                "Tensión: "
                +
                self.fmt(
                    self.sim.tension_generador,
                    1,
                    " V"
                )
            ),
            fill=NEGRO,
            anchor="w",
            font=("Helvetica", 8)
        )

        self.canvas.create_text(
            x1 + 120,
            y1 + 72,
            text=(
                "Corriente: "
                +
                self.fmt(
                    self.sim.corriente_generador,
                    1,
                    " A"
                )
            ),
            fill=NEGRO,
            anchor="w",
            font=("Helvetica", 8)
        )

        self.canvas.create_text(
            x1 + 235,
            y1 + 72,
            text=(
                "Frecuencia: "
                +
                self.fmt(
                    self.sim.frecuencia_generador,
                    2,
                    " Hz"
                )
            ),
            fill=NEGRO,
            anchor="w",
            font=("Helvetica", 8)
        )

        self.canvas.create_text(
            x1 + 20,
            y1 + 91,
            text=(
                "Potencia: "
                +
                self.fmt(
                    self.sim.potencia_generador,
                    1,
                    " kW"
                )
            ),
            fill=NEGRO,
            anchor="w",
            font=("Helvetica", 8)
        )

    # ========================================================
    # ESTADO DEL SISTEMA
    # ========================================================

    def panel_estado(self):

        x1 = 1040
        y1 = 665
        x2 = 1450
        y2 = 790

        self.canvas.create_rectangle(
            x1,
            y1,
            x2,
            y2,
            fill=FONDO_PANEL,
            outline=NEGRO
        )

        self.canvas.create_text(
            x1 + 14,
            y1 + 18,
            text="ESTADO DEL SISTEMA",
            fill=NEGRO,
            anchor="w",
            font=(
                "Helvetica",
                10,
                "bold"
            )
        )

        if not self.sim.online:

            global_estado = "SIN COMUNICACIÓN"
            global_color = ROJO

        elif self.sim.security_suspicious:

            global_estado = "ALERTA DE SEGURIDAD"
            global_color = ROJO

        elif (
            self.sim.motor_babor.estado
            ==
            DESCONOCIDO
            or
            self.sim.motor_estribor.estado
            ==
            DESCONOCIDO
        ):

            global_estado = "DATOS INCOMPLETOS"
            global_color = AMBAR

        else:

            global_estado = "NORMAL"
            global_color = VERDE

        self.canvas.create_text(
            x1 + 20,
            y1 + 50,
            text=global_estado,
            fill=global_color,
            anchor="w",
            font=(
                "Helvetica",
                15,
                "bold"
            )
        )

        self.canvas.create_text(
            x1 + 20,
            y1 + 78,
            text=(
                "Fuel: "
                +
                self.fmt(
                    self.sim.nivel_combustible,
                    1,
                    " %"
                )
                +
                "   |   Presión: "
                +
                self.fmt(
                    self.sim.presion_combustible,
                    2,
                    " bar"
                )
            ),
            fill=NEGRO,
            anchor="w",
            font=("Helvetica", 8)
        )

        self.canvas.create_text(
            x1 + 20,
            y1 + 98,
            text=(
                "Refrigeración: "
                +
                self.fmt(
                    self.sim.caudal_refrigeracion,
                    1,
                    " L/min"
                )
                +
                "   |   "
                +
                self.fmt(
                    self.sim.presion_refrigeracion,
                    2,
                    " bar"
                )
            ),
            fill=NEGRO,
            anchor="w",
            font=("Helvetica", 8)
        )

        if self.control_msg:

            color_control = (
                ROJO
                if (
                    "Error" in self.control_msg
                    or "Sin respuesta" in self.control_msg
                    or "rechazada" in self.control_msg
                )
                else AZUL
            )

            self.canvas.create_text(
                x1 + 20,
                y1 + 116,
                text=self.control_msg,
                fill=color_control,
                anchor="w",
                font=("Helvetica", 7, "bold")
            )

        elif self.export_msg:

            self.canvas.create_text(
                x1 + 20,
                y1 + 116,
                text=self.export_msg,
                fill=NEGRO,
                anchor="w",
                font=("Helvetica", 7)
            )

    # ========================================================
    # DIBUJO GLOBAL
    # ========================================================

    def dibujar_scada(self):

        self.canvas.delete(
            "all"
        )

        # ----------------------------------------------------
        # CABECERA
        # ----------------------------------------------------

        if self.logo_phasmida is not None:
            self.canvas.create_image(40, 42, image=self.logo_phasmida, anchor="w")
            titulo_x = 285
        else:
            self.canvas.create_text(40, 38, text="PHASMIDA", fill=NEGRO, anchor="w", font=("Helvetica", 20, "bold"))
            titulo_x = 210

        self.canvas.create_text(titulo_x, 34, text="CÁMARA DE MÁQUINAS", fill=NEGRO, anchor="w", font=("Helvetica", 22, "bold"))
        self.canvas.create_text(titulo_x, 62, text="SCADA DE CONTROL Y SUPERVISIÓN OT NAVAL", fill=GRIS_OSCURO, anchor="w", font=("Helvetica", 9, "bold"))
        self.canvas.create_text(titulo_x, 78, text="Máster Universitario en Industria Conectada", fill=GRIS_OSCURO, anchor="w", font=("Helvetica", 8))
        self.canvas.create_line(40, 94, 1450, 94, fill="#B5B5B5", width=1)

        # ----------------------------------------------------
        # LOGO
        # ----------------------------------------------------

        if self.logo_uned is not None:

            self.canvas.create_image(
                1435,
                40,
                image=self.logo_uned,
                anchor="e"
            )

        # ----------------------------------------------------
        # ESTADO DE COMUNICACIÓN
        # ----------------------------------------------------

        if self.sim.online:

            online_text = "● ONLINE"
            online_color = VERDE

        else:

            online_text = "● OFFLINE"
            online_color = ROJO

        self.canvas.create_text(
            1250,
            22,
            text=online_text,
            fill=online_color,
            anchor="e",
            font=(
                "Helvetica",
                10,
                "bold"
            )
        )

        self.canvas.create_text(
            1250,
            43,
            text="Fuente: PHASMIDA Core",
            fill=NEGRO,
            anchor="e",
            font=(
                "Helvetica",
                9
            )
        )

        self.canvas.create_text(
            1250,
            62,
            text="MODO CONTROL / SUPERVISIÓN",
            fill=NEGRO,
            anchor="e",
            font=(
                "Helvetica",
                8,
                "bold"
            )
        )

        # ----------------------------------------------------
        # SECCIONES
        # ----------------------------------------------------

        self.titulo_seccion(
            40,
            112,
            "LÍNEA DE PROPULSIÓN · BABOR"
        )

        self.titulo_seccion(
            40,
            390,
            "LÍNEA DE PROPULSIÓN · ESTRIBOR"
        )

        # ----------------------------------------------------
        # BABOR
        # ----------------------------------------------------

        y_bb = 215

        flujo_bb = (
            self.sim.bomba_comb_babor.estado
            ==
            NORMAL
            and
            self.sim.valvula_comb_babor.estado
            ==
            ABIERTA
            and
            self.sim.nivel_combustible is not None
            and
            self.sim.nivel_combustible > 1
        )

        if not self.sim.online:

            color_linea_bb = GRIS

        elif flujo_bb:

            color_linea_bb = VERDE

        else:

            color_linea_bb = AMBAR

        self.dibujar_deposito(
            50,
            150,
            self.sim.nivel_combustible,
            "Depósito combustible"
        )

        self.tuberia(
            140,
            y_bb,
            220,
            y_bb,
            color_linea_bb
        )

        self.dibujar_valvula(
            250,
            y_bb,
            self.sim.valvula_comb_babor
        )

        self.tuberia(
            275,
            y_bb,
            345,
            y_bb,
            color_linea_bb
        )

        self.dibujar_bomba(
            385,
            y_bb,
            self.sim.bomba_comb_babor
        )

        self.tuberia(
            415,
            y_bb,
            485,
            y_bb,
            color_linea_bb
        )

        self.dibujar_motor(
            485,
            145,
            "Motor babor",
            self.sim.motor_babor,
            self.sim.rpm_babor,
            self.sim.temp_babor,
            self.sim.presion_aceite_babor,
            self.sim.coolant_babor
        )

        color_prop_bb = (
            self.color_propulsion(
                self.sim.motor_babor,
                self.sim.rpm_babor
            )
        )

        self.canvas.create_line(
            735,
            y_bb,
            875,
            y_bb,
            fill=color_prop_bb,
            width=7
        )

        self.canvas.create_text(
            805,
            y_bb - 18,
            text="Eje babor",
            fill=NEGRO,
            font=(
                "Helvetica",
                9
            )
        )

        self.dibujar_helice(
            925,
            y_bb,
            self.sim.rpm_babor,
            "Hélice babor",
            self.angulo_helice_bb,
            color_prop_bb
        )

        # ----------------------------------------------------
        # ESTRIBOR
        # ----------------------------------------------------

        y_er = 515

        flujo_er = (
            self.sim.bomba_comb_estribor.estado
            ==
            NORMAL
            and
            self.sim.valvula_comb_estribor.estado
            ==
            ABIERTA
            and
            self.sim.nivel_combustible is not None
            and
            self.sim.nivel_combustible > 1
        )

        if not self.sim.online:

            color_linea_er = GRIS

        elif flujo_er:

            color_linea_er = VERDE

        else:

            color_linea_er = AMBAR

        self.dibujar_deposito(
            50,
            450,
            self.sim.nivel_combustible,
            "Depósito combustible"
        )

        self.tuberia(
            140,
            y_er,
            220,
            y_er,
            color_linea_er
        )

        self.dibujar_valvula(
            250,
            y_er,
            self.sim.valvula_comb_estribor
        )

        self.tuberia(
            275,
            y_er,
            345,
            y_er,
            color_linea_er
        )

        self.dibujar_bomba(
            385,
            y_er,
            self.sim.bomba_comb_estribor
        )

        self.tuberia(
            415,
            y_er,
            485,
            y_er,
            color_linea_er
        )

        self.dibujar_motor(
            485,
            445,
            "Motor estribor",
            self.sim.motor_estribor,
            self.sim.rpm_estribor,
            self.sim.temp_estribor,
            self.sim.presion_aceite_estribor,
            self.sim.coolant_estribor
        )

        color_prop_er = (
            self.color_propulsion(
                self.sim.motor_estribor,
                self.sim.rpm_estribor
            )
        )

        self.canvas.create_line(
            735,
            y_er,
            875,
            y_er,
            fill=color_prop_er,
            width=7
        )

        self.canvas.create_text(
            805,
            y_er - 18,
            text="Eje estribor",
            fill=NEGRO,
            font=(
                "Helvetica",
                9
            )
        )

        self.dibujar_helice(
            925,
            y_er,
            self.sim.rpm_estribor,
            "Hélice estribor",
            self.angulo_helice_er,
            color_prop_er
        )

        # ----------------------------------------------------
        # REFRIGERACIÓN
        # ----------------------------------------------------

        self.titulo_seccion(
            40,
            685,
            "SISTEMA DE REFRIGERACIÓN"
        )

        self.dibujar_bomba(
            205,
            735,
            self.sim.bomba_ref_1,
            "Bomba 1"
        )

        self.dibujar_bomba(
            510,
            735,
            self.sim.bomba_ref_2,
            "Bomba 2"
        )

        if not self.sim.online:

            color_ref = GRIS

        elif (
            self.sim.bomba_ref_1.estado
            ==
            NORMAL
            or
            self.sim.bomba_ref_2.estado
            ==
            NORMAL
        ):

            color_ref = VERDE

        else:

            color_ref = AMBAR

        self.tuberia(
            235,
            735,
            480,
            735,
            color_ref
        )

        self.tuberia(
            540,
            735,
            850,
            735,
            color_ref
        )

        self.canvas.create_text(
            870,
            708,
            text="Caudal",
            fill=NEGRO,
            anchor="w",
            font=(
                "Helvetica",
                8
            )
        )

        self.canvas.create_text(
            870,
            728,
            text=self.fmt(
                self.sim.caudal_refrigeracion,
                1,
                " L/min"
            ),
            fill=color_ref,
            anchor="w",
            font=(
                "Helvetica",
                10,
                "bold"
            )
        )

        self.canvas.create_text(
            870,
            750,
            text=(
                "Presión: "
                +
                self.fmt(
                    self.sim.presion_refrigeracion,
                    2,
                    " bar"
                )
            ),
            fill=NEGRO,
            anchor="w",
            font=("Helvetica", 8)
        )

        self.canvas.create_text(
            870,
            770,
            text=(
                "Temp.: "
                +
                self.fmt(
                    self.sim.temp_refrigeracion,
                    1,
                    " °C"
                )
            ),
            fill=NEGRO,
            anchor="w",
            font=("Helvetica", 8)
        )

        # ----------------------------------------------------
        # PANELES
        # ----------------------------------------------------

        self.panel_eventos()
        self.panel_electrico()
        self.panel_estado()

    # ========================================================
    # ACTUALIZACIÓN
    # ========================================================

    def actualizar(self):

        self.sim.actualizar()

        if (
            self.sim.online
            and
            self.sim.rpm_babor is not None
            and
            self.sim.rpm_babor > 50
        ):

            self.angulo_helice_bb = (
                self.angulo_helice_bb
                +
                15
            ) % 360

        if (
            self.sim.online
            and
            self.sim.rpm_estribor is not None
            and
            self.sim.rpm_estribor > 50
        ):

            self.angulo_helice_er = (
                self.angulo_helice_er
                +
                15
            ) % 360

        self.dibujar_scada()

        self.root.after(
            UPDATE_INTERVAL_MS,
            self.actualizar
        )


# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":

    root = tk.Tk()

    app = SCADA(
        root
    )

    root.mainloop()