"""
PHASMIDA Engine Node
==============================

Simulador del estado operativo de la cámara de máquinas.

Este módulo genera las principales variables de proceso
asociadas a los sistemas de propulsión y auxiliares del
buque. No implementa comunicaciones de red; únicamente
mantiene y actualiza el estado físico simulado.

El estado generado será utilizado por
iec61162_generator_udp.py para construir y transmitir
las sentencias correspondientes hacia PHASMIDA Core.

También proporciona una interfaz de control para que
componentes autorizados del entorno, como el SCADA,
puedan modificar el estado operativo del proceso.
"""

import random
from copy import deepcopy
from typing import Any


# ==========================================================
# CONFIGURACIÓN DE LA SIMULACIÓN
# ==========================================================

UPDATE_INTERVAL = 1.0


# ==========================================================
# ESTADO INICIAL DE LA CÁMARA DE MÁQUINAS
# ==========================================================

INITIAL_STATE: dict[str, Any] = {

    # ------------------------------------------------------
    # PROPULSIÓN
    # ------------------------------------------------------

    "propulsion": {

        "port": {
            "running": True,
            "rpm": 720.0,
            "temperature_c": 78.0,
            "oil_pressure_bar": 4.2,
            "coolant_temperature_c": 74.0,
            "power_kw": 850.0
        },

        "starboard": {
            "running": True,
            "rpm": 720.0,
            "temperature_c": 78.0,
            "oil_pressure_bar": 4.2,
            "coolant_temperature_c": 74.0,
            "power_kw": 850.0
        }
    },

    # ------------------------------------------------------
    # SISTEMA DE COMBUSTIBLE
    # ------------------------------------------------------

    "fuel": {
        "tank_level_percent": 82.0,

        "port_pump": True,
        "starboard_pump": True,

        "port_valve": True,
        "starboard_valve": True,

        "pressure_bar": 3.5,
        "flow_l_min": 95.0
    },

    # ------------------------------------------------------
    # SISTEMA DE REFRIGERACIÓN
    # ------------------------------------------------------

    "cooling": {
        "port_pump": True,
        "starboard_pump": True,

        "pressure_bar": 2.8,
        "temperature_c": 68.0,
        "flow_l_min": 180.0
    },

    # ------------------------------------------------------
    # SISTEMA ELÉCTRICO
    # ------------------------------------------------------

    "electrical": {
        "generator_running": True,
        "voltage_v": 400.0,
        "current_a": 120.0,
        "frequency_hz": 50.0,
        "power_kw": 75.0
    }
}


# ==========================================================
# ESTADO ACTUAL
# ==========================================================

ENGINE_STATE = deepcopy(
    INITIAL_STATE
)


# ==========================================================
# FUNCIONES AUXILIARES
# ==========================================================

def vary(
    value: float,
    variation: float,
    minimum: float | None = None,
    maximum: float | None = None
) -> float:
    """
    Introduce una pequeña variación aleatoria sobre una
    variable continua manteniéndola dentro de unos límites.
    """

    value += random.uniform(
        -variation,
        variation
    )

    if minimum is not None:
        value = max(
            minimum,
            value
        )

    if maximum is not None:
        value = min(
            maximum,
            value
        )

    return value


# ==========================================================
# ACTUALIZACIÓN DE PROPULSIÓN
# ==========================================================

def update_engine(
    engine: dict[str, Any]
) -> None:
    """
    Actualiza las variables correspondientes a un motor
    principal.
    """

    if engine["running"]:

        engine["rpm"] = vary(
            engine["rpm"],
            variation=4.0,
            minimum=650.0,
            maximum=800.0
        )

        engine["temperature_c"] = vary(
            engine["temperature_c"],
            variation=0.4,
            minimum=72.0,
            maximum=88.0
        )

        engine["oil_pressure_bar"] = vary(
            engine["oil_pressure_bar"],
            variation=0.05,
            minimum=3.5,
            maximum=5.0
        )

        engine["coolant_temperature_c"] = vary(
            engine["coolant_temperature_c"],
            variation=0.3,
            minimum=68.0,
            maximum=85.0
        )

        # Potencia aproximada relacionada con las RPM.
        engine["power_kw"] = (
            850.0
            *
            engine["rpm"]
            /
            720.0
        )

    else:

        engine["rpm"] = 0.0
        engine["power_kw"] = 0.0

        engine["temperature_c"] = max(
            25.0,
            engine["temperature_c"] - 0.2
        )

        engine["coolant_temperature_c"] = max(
            25.0,
            engine["coolant_temperature_c"] - 0.2
        )

        engine["oil_pressure_bar"] = 0.0


# ==========================================================
# ACTUALIZACIÓN DEL SISTEMA DE COMBUSTIBLE
# ==========================================================

def update_fuel_system() -> None:

    fuel = ENGINE_STATE["fuel"]

    engines_running = (
        ENGINE_STATE["propulsion"]["port"]["running"]
        or
        ENGINE_STATE["propulsion"]["starboard"]["running"]
    )

    if engines_running:

        fuel["tank_level_percent"] = max(
            0.0,
            fuel["tank_level_percent"] - 0.002
        )

    pumps_active = (
        fuel["port_pump"]
        or
        fuel["starboard_pump"]
    )

    valves_open = (
        fuel["port_valve"]
        or
        fuel["starboard_valve"]
    )

    if pumps_active and valves_open:

        fuel["pressure_bar"] = vary(
            fuel["pressure_bar"],
            variation=0.04,
            minimum=3.0,
            maximum=4.0
        )

        fuel["flow_l_min"] = vary(
            fuel["flow_l_min"],
            variation=1.5,
            minimum=80.0,
            maximum=110.0
        )

    else:

        fuel["pressure_bar"] = max(
            0.0,
            fuel["pressure_bar"] - 0.2
        )

        fuel["flow_l_min"] = max(
            0.0,
            fuel["flow_l_min"] - 5.0
        )


# ==========================================================
# ACTUALIZACIÓN DEL SISTEMA DE REFRIGERACIÓN
# ==========================================================

def update_cooling_system() -> None:

    cooling = ENGINE_STATE["cooling"]

    pumps_active = (
        cooling["port_pump"]
        or
        cooling["starboard_pump"]
    )

    if pumps_active:

        cooling["pressure_bar"] = vary(
            cooling["pressure_bar"],
            variation=0.03,
            minimum=2.4,
            maximum=3.2
        )

        cooling["flow_l_min"] = vary(
            cooling["flow_l_min"],
            variation=2.0,
            minimum=160.0,
            maximum=200.0
        )

        cooling["temperature_c"] = vary(
            cooling["temperature_c"],
            variation=0.3,
            minimum=62.0,
            maximum=75.0
        )

    else:

        cooling["pressure_bar"] = max(
            0.0,
            cooling["pressure_bar"] - 0.2
        )

        cooling["flow_l_min"] = max(
            0.0,
            cooling["flow_l_min"] - 8.0
        )

        cooling["temperature_c"] = min(
            100.0,
            cooling["temperature_c"] + 0.5
        )


# ==========================================================
# ACTUALIZACIÓN DEL SISTEMA ELÉCTRICO
# ==========================================================

def update_electrical_system() -> None:

    electrical = ENGINE_STATE["electrical"]

    if electrical["generator_running"]:

        electrical["voltage_v"] = vary(
            electrical["voltage_v"],
            variation=1.0,
            minimum=390.0,
            maximum=410.0
        )

        electrical["current_a"] = vary(
            electrical["current_a"],
            variation=2.0,
            minimum=100.0,
            maximum=140.0
        )

        electrical["frequency_hz"] = vary(
            electrical["frequency_hz"],
            variation=0.05,
            minimum=49.5,
            maximum=50.5
        )

        electrical["power_kw"] = (
            electrical["voltage_v"]
            *
            electrical["current_a"]
            *
            1.732
            *
            0.9
            /
            1000.0
        )

    else:

        electrical["voltage_v"] = 0.0
        electrical["current_a"] = 0.0
        electrical["frequency_hz"] = 0.0
        electrical["power_kw"] = 0.0


# ==========================================================
# ACTUALIZACIÓN GLOBAL
# ==========================================================

def update_state() -> dict[str, Any]:
    """
    Actualiza un ciclo completo de simulación y devuelve
    una copia del estado actual.
    """

    update_engine(
        ENGINE_STATE["propulsion"]["port"]
    )

    update_engine(
        ENGINE_STATE["propulsion"]["starboard"]
    )

    update_fuel_system()
    update_cooling_system()
    update_electrical_system()

    return deepcopy(
        ENGINE_STATE
    )


# ==========================================================
# CONSULTA DEL ESTADO
# ==========================================================

def get_state() -> dict[str, Any]:
    """
    Devuelve una copia del estado actual sin modificarlo.
    """

    return deepcopy(
        ENGINE_STATE
    )


# ==========================================================
# RESET
# ==========================================================

def reset_state() -> dict[str, Any]:
    """
    Restablece la cámara de máquinas a su estado inicial.
    """

    global ENGINE_STATE

    ENGINE_STATE = deepcopy(
        INITIAL_STATE
    )

    return get_state()


# ==========================================================
# INTERFAZ DE CONTROL DEL PROCESO
# ==========================================================

VALID_CONTROL_TARGETS = {
    "FUEL_PORT_PUMP",
    "FUEL_STBD_PUMP",
    "FUEL_PORT_VALVE",
    "FUEL_STBD_VALVE",
    "COOL_PORT_PUMP",
    "COOL_STBD_PUMP",
    "ENGINE_PORT",
    "ENGINE_STBD",
    "GENERATOR",
}


def get_control_value(
    target: str
) -> bool:
    """
    Obtiene el estado booleano asociado a un elemento
    controlable de la cámara de máquinas.
    """

    if target == "FUEL_PORT_PUMP":

        return bool(
            ENGINE_STATE["fuel"]["port_pump"]
        )

    if target == "FUEL_STBD_PUMP":

        return bool(
            ENGINE_STATE["fuel"]["starboard_pump"]
        )

    if target == "FUEL_PORT_VALVE":

        return bool(
            ENGINE_STATE["fuel"]["port_valve"]
        )

    if target == "FUEL_STBD_VALVE":

        return bool(
            ENGINE_STATE["fuel"]["starboard_valve"]
        )

    if target == "COOL_PORT_PUMP":

        return bool(
            ENGINE_STATE["cooling"]["port_pump"]
        )

    if target == "COOL_STBD_PUMP":

        return bool(
            ENGINE_STATE["cooling"]["starboard_pump"]
        )

    if target == "ENGINE_PORT":

        return bool(
            ENGINE_STATE[
                "propulsion"
            ][
                "port"
            ][
                "running"
            ]
        )

    if target == "ENGINE_STBD":

        return bool(
            ENGINE_STATE[
                "propulsion"
            ][
                "starboard"
            ][
                "running"
            ]
        )

    if target == "GENERATOR":

        return bool(
            ENGINE_STATE[
                "electrical"
            ][
                "generator_running"
            ]
        )

    raise ValueError(
        f"Elemento de control desconocido: {target}"
    )


def set_control_value(
    target: str,
    value: bool
) -> bool:
    """
    Establece explícitamente el estado de un elemento
    controlable.

    Devuelve el nuevo estado aplicado.
    """

    if target not in VALID_CONTROL_TARGETS:

        raise ValueError(
            f"Elemento de control desconocido: {target}"
        )

    value = bool(
        value
    )

    # ------------------------------------------------------
    # COMBUSTIBLE
    # ------------------------------------------------------

    if target == "FUEL_PORT_PUMP":

        ENGINE_STATE[
            "fuel"
        ][
            "port_pump"
        ] = value

    elif target == "FUEL_STBD_PUMP":

        ENGINE_STATE[
            "fuel"
        ][
            "starboard_pump"
        ] = value

    elif target == "FUEL_PORT_VALVE":

        ENGINE_STATE[
            "fuel"
        ][
            "port_valve"
        ] = value

    elif target == "FUEL_STBD_VALVE":

        ENGINE_STATE[
            "fuel"
        ][
            "starboard_valve"
        ] = value

    # ------------------------------------------------------
    # REFRIGERACIÓN
    # ------------------------------------------------------

    elif target == "COOL_PORT_PUMP":

        ENGINE_STATE[
            "cooling"
        ][
            "port_pump"
        ] = value

    elif target == "COOL_STBD_PUMP":

        ENGINE_STATE[
            "cooling"
        ][
            "starboard_pump"
        ] = value

    # ------------------------------------------------------
    # PROPULSIÓN
    # ------------------------------------------------------

    elif target == "ENGINE_PORT":

        engine = ENGINE_STATE[
            "propulsion"
        ][
            "port"
        ]

        engine[
            "running"
        ] = value

        if value:

            # El motor vuelve a un régimen inicial válido
            # cuando se arranca desde estado parado.
            if engine["rpm"] <= 0.0:

                engine["rpm"] = 720.0

            if engine["oil_pressure_bar"] <= 0.0:

                engine["oil_pressure_bar"] = 4.2

        else:

            engine["rpm"] = 0.0
            engine["power_kw"] = 0.0
            engine["oil_pressure_bar"] = 0.0

    elif target == "ENGINE_STBD":

        engine = ENGINE_STATE[
            "propulsion"
        ][
            "starboard"
        ]

        engine[
            "running"
        ] = value

        if value:

            if engine["rpm"] <= 0.0:

                engine["rpm"] = 720.0

            if engine["oil_pressure_bar"] <= 0.0:

                engine["oil_pressure_bar"] = 4.2

        else:

            engine["rpm"] = 0.0
            engine["power_kw"] = 0.0
            engine["oil_pressure_bar"] = 0.0

    # ------------------------------------------------------
    # GENERADOR
    # ------------------------------------------------------

    elif target == "GENERATOR":

        electrical = ENGINE_STATE[
            "electrical"
        ]

        electrical[
            "generator_running"
        ] = value

        if value:

            if electrical["voltage_v"] <= 0.0:
                electrical["voltage_v"] = 400.0

            if electrical["current_a"] <= 0.0:
                electrical["current_a"] = 120.0

            if electrical["frequency_hz"] <= 0.0:
                electrical["frequency_hz"] = 50.0

            if electrical["power_kw"] <= 0.0:
                electrical["power_kw"] = 75.0

        else:

            electrical["voltage_v"] = 0.0
            electrical["current_a"] = 0.0
            electrical["frequency_hz"] = 0.0
            electrical["power_kw"] = 0.0

    return get_control_value(
        target
    )


def toggle_control(
    target: str
) -> bool:
    """
    Invierte el estado de un elemento controlable.

    Ejemplo:

        FUEL_PORT_PUMP:
            True -> False
            False -> True
    """

    current_value = get_control_value(
        target
    )

    return set_control_value(
        target,
        not current_value
    )


def apply_control_command(
    command: str,
    target: str | None = None,
    value: bool | None = None
) -> dict[str, Any]:
    """
    Procesa una orden procedente de un componente autorizado,
    como el SCADA PHASMIDA.

    Órdenes soportadas:

        TOGGLE
        SET
        RESET

    Ejemplos:

        apply_control_command(
            "TOGGLE",
            "FUEL_PORT_PUMP"
        )

        apply_control_command(
            "SET",
            "ENGINE_PORT",
            False
        )

        apply_control_command(
            "RESET"
        )

    Devuelve información sobre la orden ejecutada.
    """

    command = str(
        command
    ).strip().upper()

    if target is not None:

        target = str(
            target
        ).strip().upper()

    # ------------------------------------------------------
    # RESET COMPLETO
    # ------------------------------------------------------

    if command == "RESET":

        state = reset_state()

        return {
            "success": True,
            "command": "RESET",
            "target": "SYSTEM",
            "value": None,
            "state": state
        }

    # ------------------------------------------------------
    # VALIDACIÓN DEL TARGET
    # ------------------------------------------------------

    if target is None:

        raise ValueError(
            "La orden necesita un elemento objetivo"
        )

    if target not in VALID_CONTROL_TARGETS:

        raise ValueError(
            f"Elemento de control desconocido: {target}"
        )

    # ------------------------------------------------------
    # TOGGLE
    # ------------------------------------------------------

    if command == "TOGGLE":

        new_value = toggle_control(
            target
        )

        return {
            "success": True,
            "command": command,
            "target": target,
            "value": new_value
        }

    # ------------------------------------------------------
    # SET
    # ------------------------------------------------------

    if command == "SET":

        if value is None:

            raise ValueError(
                "La orden SET necesita un valor"
            )

        if not isinstance(
            value,
            bool
        ):

            raise ValueError(
                "El valor de SET debe ser booleano"
            )

        new_value = set_control_value(
            target,
            value
        )

        return {
            "success": True,
            "command": command,
            "target": target,
            "value": new_value
        }

    raise ValueError(
        f"Orden de control desconocida: {command}"
    )