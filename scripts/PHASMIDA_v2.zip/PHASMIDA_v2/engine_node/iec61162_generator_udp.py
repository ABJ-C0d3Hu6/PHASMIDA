"""
PHASMIDA Engine Node - IEC 61162 UDP Generator
================================================

Generador de telemetría de cámara de máquinas para PHASMIDA.

El módulo obtiene el estado físico simulado desde
engine_generator.py, construye sentencias de la familia
IEC 61162/NMEA y las transmite mediante UDP hacia
PHASMIDA Core.

Además, implementa un canal UDP independiente para recibir
órdenes legítimas procedentes del SCADA PHASMIDA.

IMPORTANTE
----------
Las sentencias RPM y XDR se emplean como representación
de variables continuas del proceso.

Las sentencias PHSMD constituyen una extensión propietaria
experimental de PHASMIDA para representar estados discretos
de equipos. No constituyen una sentencia normalizada IEC 61162.
"""

import hashlib
import hmac
import json
import os
import socket
import threading
import time
from datetime import datetime, timezone

try:
    from engine_generator import (
        update_state,
        apply_control_command
    )
except ImportError:
    from engine_node.engine_generator import (
        update_state,
        apply_control_command
    )


# ==========================================================
# CONFIGURACIÓN
# ==========================================================

CORE_HOST = os.getenv(
    "PHASMIDA_CORE_HOST",
    "phasmida_core"
)

CORE_PORT = int(
    os.getenv(
        "PHASMIDA_CORE_PORT",
        "10120"
    )
)

CONTROL_HOST = os.getenv(
    "PHASMIDA_CONTROL_HOST",
    "0.0.0.0"
)

CONTROL_PORT = int(
    os.getenv(
        "PHASMIDA_CONTROL_PORT",
        "10130"
    )
)

SEND_INTERVAL = 1.0

SECRET_KEY = b"PHASMIDA_SECRET_2026"

SENSOR_NAME = "engine_node"

TALKER_ID = "II"


# ==========================================================
# CHECKSUM IEC 61162 / NMEA
# ==========================================================

def checksum(body: str) -> str:
    """
    Calcula el checksum XOR de una sentencia.
    """

    value = 0

    for character in body:
        value ^= ord(character)

    return f"{value:02X}"


def build(body: str) -> str:
    """
    Construye una sentencia completa:

        $BODY*CHECKSUM
    """

    return f"${body}*{checksum(body)}"


# ==========================================================
# RPM
# ==========================================================

def generate_rpm(
    engine_number: int,
    rpm: float,
    running: bool
) -> str:
    """
    Genera una sentencia RPM.

    engine_number:
        1 -> estribor
        2 -> babor
    """

    status = (
        "A"
        if running
        else "V"
    )

    body = (
        f"{TALKER_ID}RPM,"
        f"E,"
        f"{engine_number},"
        f"{rpm:.1f},,"
        f"{status}"
    )

    return build(body)


# ==========================================================
# XDR
# ==========================================================

def generate_xdr(
    transducers: list[tuple[str, float, str, str]]
) -> str:
    """
    Construye una sentencia XDR.

    Cada transductor se representa mediante:

        tipo, valor, unidad, identificador

    Se limita a cuatro transductores por sentencia.
    """

    fields = []

    for (
        transducer_type,
        value,
        unit,
        identifier
    ) in transducers[:4]:

        fields.extend(
            [
                transducer_type,
                f"{value:.2f}",
                unit,
                identifier
            ]
        )

    body = (
        f"{TALKER_ID}XDR,"
        +
        ",".join(fields)
    )

    return build(body)


# ==========================================================
# EXTENSIÓN PROPIETARIA PHASMIDA
# ==========================================================

def generate_phasmida_state(
    identifier: str,
    state: bool
) -> str:
    """
    Genera una sentencia experimental PHASMIDA para estados
    discretos del proceso.

    Formato:

        $PHSMD,STATE,<IDENTIFICADOR>,<0|1>*hh

    Esta sentencia es propia de PHASMIDA y no constituye
    una implementación normativa IEC 61162.
    """

    value = (
        "1"
        if state
        else "0"
    )

    body = (
        f"PHSMD,STATE,"
        f"{identifier},"
        f"{value}"
    )

    return build(body)


# ==========================================================
# CONSTRUCCIÓN DE TELEMETRÍA
# ==========================================================

def build_engine_sentences(
    state: dict
) -> list[str]:
    """
    Convierte el estado completo de la cámara de máquinas
    en las sentencias transmitidas hacia PHASMIDA Core.
    """

    sentences = []

    propulsion = state[
        "propulsion"
    ]

    fuel = state[
        "fuel"
    ]

    cooling = state[
        "cooling"
    ]

    electrical = state[
        "electrical"
    ]

    port = propulsion[
        "port"
    ]

    starboard = propulsion[
        "starboard"
    ]

    # ======================================================
    # 1-2. RPM MOTORES
    # ======================================================

    sentences.append(
        generate_rpm(
            engine_number=1,
            rpm=starboard["rpm"],
            running=starboard["running"]
        )
    )

    sentences.append(
        generate_rpm(
            engine_number=2,
            rpm=port["rpm"],
            running=port["running"]
        )
    )

    # ======================================================
    # 3. TEMPERATURAS
    # ======================================================

    sentences.append(
        generate_xdr(
            [
                (
                    "C",
                    port["temperature_c"],
                    "C",
                    "ENG_PORT_TEMP"
                ),
                (
                    "C",
                    starboard["temperature_c"],
                    "C",
                    "ENG_STBD_TEMP"
                ),
                (
                    "C",
                    port["coolant_temperature_c"],
                    "C",
                    "COOL_PORT_TEMP"
                ),
                (
                    "C",
                    starboard["coolant_temperature_c"],
                    "C",
                    "COOL_STBD_TEMP"
                )
            ]
        )
    )

    # ======================================================
    # 4. PRESIONES
    # ======================================================

    sentences.append(
        generate_xdr(
            [
                (
                    "P",
                    port["oil_pressure_bar"],
                    "B",
                    "OIL_PORT_PRESS"
                ),
                (
                    "P",
                    starboard["oil_pressure_bar"],
                    "B",
                    "OIL_STBD_PRESS"
                ),
                (
                    "P",
                    fuel["pressure_bar"],
                    "B",
                    "FUEL_PRESS"
                ),
                (
                    "P",
                    cooling["pressure_bar"],
                    "B",
                    "COOL_PRESS"
                )
            ]
        )
    )

    # ======================================================
    # 5. TEMPERATURA REFRIGERACIÓN
    # ======================================================

    sentences.append(
        generate_xdr(
            [
                (
                    "C",
                    cooling["temperature_c"],
                    "C",
                    "COOL_SYS_TEMP"
                )
            ]
        )
    )

    # ======================================================
    # 6. FRECUENCIA GENERADOR
    # ======================================================

    sentences.append(
        generate_xdr(
            [
                (
                    "F",
                    electrical["frequency_hz"],
                    "H",
                    "GEN_FREQ"
                )
            ]
        )
    )

    # ======================================================
    # 7. POTENCIA DE PROPULSIÓN
    # ======================================================

    sentences.append(
        generate_xdr(
            [
                (
                    "W",
                    port["power_kw"],
                    "K",
                    "ENG_PORT_POWER"
                ),
                (
                    "W",
                    starboard["power_kw"],
                    "K",
                    "ENG_STBD_POWER"
                )
            ]
        )
    )

    # ======================================================
    # 8. COMBUSTIBLE
    # ======================================================

    sentences.append(
        generate_xdr(
            [
                (
                    "L",
                    fuel["tank_level_percent"],
                    "P",
                    "FUEL_TANK_LEVEL"
                ),
                (
                    "R",
                    fuel["flow_l_min"],
                    "L",
                    "FUEL_FLOW"
                )
            ]
        )
    )

    # ======================================================
    # 9. CAUDAL REFRIGERACIÓN
    # ======================================================

    sentences.append(
        generate_xdr(
            [
                (
                    "R",
                    cooling["flow_l_min"],
                    "L",
                    "COOL_FLOW"
                )
            ]
        )
    )

    # ======================================================
    # 10. SISTEMA ELÉCTRICO
    # ======================================================

    sentences.append(
        generate_xdr(
            [
                (
                    "U",
                    electrical["voltage_v"],
                    "V",
                    "GEN_VOLTAGE"
                ),
                (
                    "I",
                    electrical["current_a"],
                    "A",
                    "GEN_CURRENT"
                ),
                (
                    "W",
                    electrical["power_kw"],
                    "K",
                    "GEN_POWER"
                )
            ]
        )
    )

    # ======================================================
    # 11-17. ESTADOS DISCRETOS PHASMIDA
    # ======================================================

    sentences.append(
        generate_phasmida_state(
            "FUEL_PORT_PUMP",
            fuel["port_pump"]
        )
    )

    sentences.append(
        generate_phasmida_state(
            "FUEL_STBD_PUMP",
            fuel["starboard_pump"]
        )
    )

    sentences.append(
        generate_phasmida_state(
            "FUEL_PORT_VALVE",
            fuel["port_valve"]
        )
    )

    sentences.append(
        generate_phasmida_state(
            "FUEL_STBD_VALVE",
            fuel["starboard_valve"]
        )
    )

    sentences.append(
        generate_phasmida_state(
            "COOL_PORT_PUMP",
            cooling["port_pump"]
        )
    )

    sentences.append(
        generate_phasmida_state(
            "COOL_STBD_PUMP",
            cooling["starboard_pump"]
        )
    )

    sentences.append(
        generate_phasmida_state(
            "GEN_RUNNING",
            electrical["generator_running"]
        )
    )

    return sentences


# ==========================================================
# MENSAJE SEGURO PHASMIDA
# ==========================================================

def calculate_hmac(
    sentence: str,
    timestamp: str,
    sensor: str
) -> str:
    """
    Calcula la firma HMAC utilizada por PHASMIDA.
    """

    payload = (
        f"{sentence}|"
        f"{timestamp}|"
        f"{sensor}"
    )

    return hmac.new(
        SECRET_KEY,
        payload.encode("utf-8"),
        hashlib.sha256
    ).hexdigest()


def build_secure_message(
    sentence: str
) -> dict:
    """
    Construye el sobre JSON seguro utilizado entre los
    nodos de PHASMIDA y PHASMIDA Core.

    Se conserva la clave 'nmea' por compatibilidad con la
    arquitectura original.
    """

    timestamp = (
        datetime.now(
            timezone.utc
        ).isoformat()
    )

    signature = calculate_hmac(
        sentence,
        timestamp,
        SENSOR_NAME
    )

    return {
        "sensor": SENSOR_NAME,
        "timestamp": timestamp,
        "nmea": sentence,
        "hmac": signature
    }


# ==========================================================
# RESPUESTA DEL CANAL DE CONTROL
# ==========================================================

def build_control_response(
    success: bool,
    command: str | None = None,
    target: str | None = None,
    value=None,
    error: str | None = None
) -> dict:
    """
    Construye la respuesta enviada al SCADA tras procesar
    una orden.
    """

    response = {
        "source": "engine_node",
        "timestamp": datetime.now(
            timezone.utc
        ).isoformat(),
        "success": success
    }

    if command is not None:
        response["command"] = command

    if target is not None:
        response["target"] = target

    if value is not None:
        response["value"] = value

    if error is not None:
        response["error"] = error

    return response


# ==========================================================
# PROCESAMIENTO DE ÓRDENES SCADA
# ==========================================================

def process_control_message(
    raw_data: bytes,
    source_address
) -> dict:
    """
    Valida y procesa una orden recibida por el canal de
    control del engine_node.

    Formato esperado:

        {
            "source": "scada_phasmida",
            "command": "TOGGLE",
            "target": "FUEL_PORT_PUMP"
        }

    También se soportan SET y RESET.
    """

    source_ip = source_address[0]

    try:

        message = json.loads(
            raw_data.decode("utf-8")
        )

    except (
        UnicodeDecodeError,
        json.JSONDecodeError
    ):

        return build_control_response(
            success=False,
            error="INVALID_JSON"
        )

    if not isinstance(
        message,
        dict
    ):

        return build_control_response(
            success=False,
            error="INVALID_MESSAGE_FORMAT"
        )

    source = message.get(
        "source"
    )

    if source != "scada_phasmida":

        return build_control_response(
            success=False,
            error="UNAUTHORIZED_CONTROL_SOURCE"
        )

    command = str(
        message.get(
            "command",
            ""
        )
    ).strip().upper()

    target = message.get(
        "target"
    )

    if target is not None:

        target = str(
            target
        ).strip().upper()

    value = message.get(
        "value"
    )

    try:

        result = apply_control_command(
            command=command,
            target=target,
            value=value
        )

    except ValueError as error:

        return build_control_response(
            success=False,
            command=command,
            target=target,
            error=str(error)
        )

    print(
        f"[SCADA CONTROL] "
        f"{source_ip} -> "
        f"{command} "
        f"{target or 'SYSTEM'} "
        f"=> {result.get('value')}",
        flush=True
    )

    return build_control_response(
        success=True,
        command=result.get(
            "command"
        ),
        target=result.get(
            "target"
        ),
        value=result.get(
            "value"
        )
    )


# ==========================================================
# SERVIDOR UDP DE CONTROL
# ==========================================================

def control_server(
    stop_event: threading.Event
) -> None:
    """
    Hilo encargado de recibir órdenes legítimas del SCADA.

    Este canal es independiente de la transmisión de
    telemetría hacia PHASMIDA Core.
    """

    control_socket = socket.socket(
        socket.AF_INET,
        socket.SOCK_DGRAM
    )

    control_socket.setsockopt(
        socket.SOL_SOCKET,
        socket.SO_REUSEADDR,
        1
    )

    try:

        control_socket.bind(
            (
                CONTROL_HOST,
                CONTROL_PORT
            )
        )

    except OSError as error:

        print(
            f"[CONTROL ERROR] "
            f"No se puede abrir "
            f"{CONTROL_HOST}:{CONTROL_PORT}: "
            f"{error}",
            flush=True
        )

        control_socket.close()
        return

    # El timeout permite comprobar periódicamente si el
    # proceso principal ha solicitado finalizar.
    control_socket.settimeout(
        1.0
    )

    print(
        f"[CONTROL] Canal SCADA escuchando en "
        f"{CONTROL_HOST}:{CONTROL_PORT}",
        flush=True
    )

    try:

        while not stop_event.is_set():

            try:

                raw_data, source_address = (
                    control_socket.recvfrom(
                        65535
                    )
                )

            except socket.timeout:

                continue

            except OSError:

                break

            response = process_control_message(
                raw_data,
                source_address
            )

            try:

                control_socket.sendto(
                    json.dumps(
                        response
                    ).encode(
                        "utf-8"
                    ),
                    source_address
                )

            except OSError as error:

                print(
                    f"[CONTROL ERROR] "
                    f"No se pudo enviar ACK: "
                    f"{error}",
                    flush=True
                )

    finally:

        control_socket.close()

        print(
            "[CONTROL] Canal SCADA detenido.",
            flush=True
        )


# ==========================================================
# EJECUCIÓN PRINCIPAL
# ==========================================================

def main() -> None:

    telemetry_socket = socket.socket(
        socket.AF_INET,
        socket.SOCK_DGRAM
    )

    stop_event = threading.Event()

    control_thread = threading.Thread(
        target=control_server,
        args=(stop_event,),
        name="phasmida-scada-control",
        daemon=True
    )

    control_thread.start()

    print(
        f"PHASMIDA Engine Node enviando telemetría a "
        f"{CORE_HOST}:{CORE_PORT}",
        flush=True
    )

    print(
        f"Canal de control SCADA: "
        f"{CONTROL_HOST}:{CONTROL_PORT}",
        flush=True
    )

    try:

        while True:

            # ------------------------------------------------
            # ACTUALIZACIÓN DEL PROCESO FÍSICO
            # ------------------------------------------------

            state = update_state()

            # ------------------------------------------------
            # CONSTRUCCIÓN DE SENTENCIAS
            # ------------------------------------------------

            sentences = build_engine_sentences(
                state
            )

            # ------------------------------------------------
            # TRANSMISIÓN A PHASMIDA CORE
            # ------------------------------------------------

            for sentence in sentences:

                message = build_secure_message(
                    sentence
                )

                telemetry_socket.sendto(
                    json.dumps(
                        message
                    ).encode(
                        "utf-8"
                    ),
                    (
                        CORE_HOST,
                        CORE_PORT
                    )
                )

                print(
                    f"[ENGINE TX] {sentence}",
                    flush=True
                )

            time.sleep(
                SEND_INTERVAL
            )

    except KeyboardInterrupt:

        print(
            "\nPHASMIDA Engine Node detenido.",
            flush=True
        )

    finally:

        stop_event.set()

        telemetry_socket.close()

        control_thread.join(
            timeout=2.0
        )


if __name__ == "__main__":
    main()