"""
PHASMIDA Shared State
==============================

Gestión del estado compartido de PHASMIDA.

Este módulo mantiene el estado global utilizado por los
distintos componentes de la plataforma, incluyendo:

    - Navegación.
    - Posicionamiento.
    - Profundidad.
    - Propulsión.
    - Sistema de combustible.
    - Sistema de refrigeración.
    - Sistema eléctrico.
    - Histórico de navegación.
    - Estado de seguridad.

El estado se almacena en formato JSON y se actualiza de
forma atómica para evitar lecturas parciales por parte de
otros componentes, como el SCADA o los dashboards.
"""

import json
import os
import tempfile
from copy import deepcopy
from datetime import datetime, timezone
from typing import Any


# ==========================================================
# CONFIGURACIÓN
# ==========================================================

STATE_FILE = os.getenv(
    "PHASMIDA_STATE_FILE",
    "events/nmea_state.json"
)


# ==========================================================
# ESTADO GLOBAL PHASMIDA
# ==========================================================

DEFAULT_STATE: dict[str, Any] = {

    # ------------------------------------------------------
    # METADATOS
    # ------------------------------------------------------

    "updated_at": None,
    "source_ip": None,
    "last_sentence": None,
    "last_sentence_type": None,
    "last_talker_id": None,

    # ------------------------------------------------------
    # NAVEGACIÓN
    # ------------------------------------------------------

    "position": {
        "latitude": None,
        "longitude": None,
        "altitude_m": None
    },

    "navigation": {
        "speed_knots": None,
        "course_deg": None,
        "heading_deg": None
    },

    "depth": {
        "meters": None
    },

    # ------------------------------------------------------
    # PROPULSIÓN
    # ------------------------------------------------------

    "propulsion": {

        "port": {
            "running": None,
            "rpm": None,
            "temperature_c": None,
            "oil_pressure_bar": None,
            "coolant_temperature_c": None,
            "power_kw": None
        },

        "starboard": {
            "running": None,
            "rpm": None,
            "temperature_c": None,
            "oil_pressure_bar": None,
            "coolant_temperature_c": None,
            "power_kw": None
        }
    },

    # ------------------------------------------------------
    # SISTEMA DE COMBUSTIBLE
    # ------------------------------------------------------

    "fuel": {
        "tank_level_percent": None,

        "port_pump": None,
        "starboard_pump": None,

        "port_valve": None,
        "starboard_valve": None,

        "pressure_bar": None,
        "flow_l_min": None
    },

    # ------------------------------------------------------
    # SISTEMA DE REFRIGERACIÓN
    # ------------------------------------------------------

    "cooling": {
        "port_pump": None,
        "starboard_pump": None,

        "pressure_bar": None,
        "temperature_c": None,
        "flow_l_min": None
    },

    # ------------------------------------------------------
    # SISTEMA ELÉCTRICO
    # ------------------------------------------------------

    "electrical": {
        "generator_running": None,
        "voltage_v": None,
        "current_a": None,
        "frequency_hz": None,
        "power_kw": None
    },

    # ------------------------------------------------------
    # HISTÓRICO DE NAVEGACIÓN
    # ------------------------------------------------------

    "track": [],

    # ------------------------------------------------------
    # SEGURIDAD
    # ------------------------------------------------------

    "security": {
        "suspicious": False,
        "alerts": []
    }
}


# ==========================================================
# ACTUALIZACIÓN RECURSIVA
# ==========================================================

def deep_update(
    target: dict[str, Any],
    updates: dict[str, Any]
) -> None:
    """
    Actualiza recursivamente un diccionario.

    Las claves que no aparecen en la actualización se
    conservan. Esto permite modificar variables concretas
    de estructuras anidadas sin eliminar el resto del estado.

    Ejemplo:

        propulsion.port.rpm

    puede actualizarse sin eliminar:

        propulsion.port.temperature_c
        propulsion.port.oil_pressure_bar
        propulsion.port.power_kw
    """

    for key, value in updates.items():

        if (
            key in target
            and isinstance(target[key], dict)
            and isinstance(value, dict)
        ):
            deep_update(
                target[key],
                value
            )

        else:
            target[key] = deepcopy(value)


# ==========================================================
# GESTIÓN DEL DIRECTORIO DE ESTADO
# ==========================================================

def ensure_state_directory() -> None:
    """
    Crea el directorio destinado al archivo de estado
    si todavía no existe.
    """

    directory = os.path.dirname(
        STATE_FILE
    )

    if directory:
        os.makedirs(
            directory,
            exist_ok=True
        )


# ==========================================================
# LECTURA DEL ESTADO
# ==========================================================

def read_state() -> dict[str, Any]:
    """
    Lee el estado almacenado en disco.

    Siempre se parte de DEFAULT_STATE para garantizar que
    nuevas variables introducidas en PHASMIDA estén
    disponibles aunque el archivo JSON proceda de una
    versión anterior.
    """

    ensure_state_directory()

    if not os.path.exists(
        STATE_FILE
    ):
        return deepcopy(
            DEFAULT_STATE
        )

    try:

        with open(
            STATE_FILE,
            "r",
            encoding="utf-8"
        ) as file:

            data = json.load(
                file
            )

        if not isinstance(
            data,
            dict
        ):
            return deepcopy(
                DEFAULT_STATE
            )

        state = deepcopy(
            DEFAULT_STATE
        )

        # Fusión recursiva para mantener la estructura
        # completa aunque el JSON almacenado sea parcial
        # o proceda de una versión anterior.
        deep_update(
            state,
            data
        )

        return state

    except (
        OSError,
        json.JSONDecodeError
    ):

        return deepcopy(
            DEFAULT_STATE
        )


# ==========================================================
# ESCRITURA DEL ESTADO
# ==========================================================

def write_state(
    state: dict[str, Any]
) -> None:
    """
    Escribe el estado mediante un archivo temporal y una
    sustitución atómica.

    Esto evita que otros procesos lean un JSON parcialmente
    escrito mientras PHASMIDA actualiza el estado.
    """

    ensure_state_directory()

    directory = (
        os.path.dirname(
            STATE_FILE
        )
        or "."
    )

    file_descriptor, temporary_path = tempfile.mkstemp(
        dir=directory,
        prefix=".nmea_state_",
        suffix=".json"
    )

    try:

        with os.fdopen(
            file_descriptor,
            "w",
            encoding="utf-8"
        ) as file:

            json.dump(
                state,
                file,
                ensure_ascii=False,
                indent=2
            )

        os.replace(
            temporary_path,
            STATE_FILE
        )

    except Exception:

        if os.path.exists(
            temporary_path
        ):
            os.remove(
                temporary_path
            )

        raise


# ==========================================================
# ACTUALIZACIÓN DEL ESTADO
# ==========================================================

def update_state(
    updates: dict[str, Any],
    source_ip: str | None = None,
    sentence: str | None = None,
    sentence_type: str | None = None,
    talker_id: str | None = None,
    suspicious: bool | None = None,
    alerts: list[str] | None = None
) -> dict[str, Any]:
    """
    Actualiza el estado global de PHASMIDA.

    Las variables de proceso se fusionan recursivamente,
    mientras que los metadatos de la última comunicación
    recibida y el estado de seguridad se actualizan de
    manera independiente.
    """

    state = read_state()

    # ------------------------------------------------------
    # VARIABLES DE NAVEGACIÓN Y PROCESO
    # ------------------------------------------------------

    if updates:
        deep_update(
            state,
            updates
        )

    # ------------------------------------------------------
    # METADATOS
    # ------------------------------------------------------

    state["updated_at"] = datetime.now(
        timezone.utc
    ).isoformat()

    if source_ip is not None:
        state["source_ip"] = source_ip

    if sentence is not None:
        state["last_sentence"] = sentence

    if sentence_type is not None:
        state["last_sentence_type"] = sentence_type

    if talker_id is not None:
        state["last_talker_id"] = talker_id

    # ------------------------------------------------------
    # SEGURIDAD
    # ------------------------------------------------------

    security = state.setdefault(
        "security",
        {
            "suspicious": False,
            "alerts": []
        }
    )

    if suspicious is not None:
        security["suspicious"] = suspicious

    if alerts is not None:
        security["alerts"] = deepcopy(
            alerts
        )

    # ------------------------------------------------------
    # TRACK DE NAVEGACIÓN
    # ------------------------------------------------------

    position = state.get(
        "position",
        {}
    )

    latitude = position.get(
        "latitude"
    )

    longitude = position.get(
        "longitude"
    )

    if (
        latitude is not None
        and longitude is not None
    ):

        track = state.setdefault(
            "track",
            []
        )

        new_point = {
            "lat": float(latitude),
            "lon": float(longitude),
            "timestamp": state["updated_at"]
        }

        if not track:

            track.append(
                new_point
            )

        else:

            last_point = track[-1]

            if (
                last_point.get("lat")
                != new_point["lat"]
                or
                last_point.get("lon")
                != new_point["lon"]
            ):

                track.append(
                    new_point
                )

        # Limitar el histórico para evitar un crecimiento
        # indefinido del archivo de estado.
        state["track"] = track[-500:]

    # ------------------------------------------------------
    # PERSISTENCIA
    # ------------------------------------------------------

    write_state(
        state
    )

    return state
