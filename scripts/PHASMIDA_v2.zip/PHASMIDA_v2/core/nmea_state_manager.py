"""
PHASMIDA Core
==============================

NMEA / IEC 61162 State Manager

Responsabilidades:
    - Recibir mensajes PHASMIDA Secure.
    - Interpretar el estado de navegación.
    - Delegar el tratamiento de las sentencias IEC 61162
      asociadas a maquinaria y propulsión.
    - Mantener un estado común para las visualizaciones.
    - Reenviar el mensaje original al IDS.

Este módulo conserva el funcionamiento del NMEA State Manager
original de PHASMIDA y lo amplía mediante IEC61162StateManager
para incorporar la monitorización de la cámara de máquinas.
"""

import json
import os
import socket
import sys
from pathlib import Path


# ==========================================================
# RUTAS DEL PROYECTO
# ==========================================================

PROJECT_ROOT = Path(__file__).resolve().parent.parent

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(
        0,
        str(PROJECT_ROOT)
    )


# ==========================================================
# MÓDULOS PHASMIDA
# ==========================================================

from shared.nmea_state import update_state
from core.iec61162_state_manager import IEC61162StateManager


class NMEAStateManager:

    # ======================================================
    # INICIALIZACIÓN
    # ======================================================

    def __init__(
        self,
        host: str = "0.0.0.0",
        port: int = 10120,
        ids_host: str | None = None,
        ids_port: int | None = None
    ) -> None:

        self.host = host
        self.port = port

        # Permite mantener los valores originales y, al mismo
        # tiempo, configurarlos desde Docker mediante variables
        # de entorno.
        self.ids_host = (
            ids_host
            or os.getenv(
                "PHASMIDA_IDS_HOST",
                "phasmida_ids"
            )
        )

        self.ids_port = (
            ids_port
            if ids_port is not None
            else int(
                os.getenv(
                    "PHASMIDA_IDS_PORT",
                    "10110"
                )
            )
        )

        # --------------------------------------------------
        # GESTOR IEC 61162 DE MAQUINARIA
        # --------------------------------------------------

        self.iec61162_manager = IEC61162StateManager()

        # --------------------------------------------------
        # SOCKET DE RECEPCIÓN
        # --------------------------------------------------

        self.receive_socket = socket.socket(
            socket.AF_INET,
            socket.SOCK_DGRAM
        )

        self.receive_socket.bind(
            (
                self.host,
                self.port
            )
        )

        # --------------------------------------------------
        # SOCKET DE REENVÍO AL IDS
        # --------------------------------------------------

        self.forward_socket = socket.socket(
            socket.AF_INET,
            socket.SOCK_DGRAM
        )

        print("=" * 60)
        print("PHASMIDA Core")
        print("NMEA / IEC 61162 State Manager iniciado")
        print(
            f"Escuchando en "
            f"{self.host}:{self.port}"
        )
        print(
            f"Reenvío IDS: "
            f"{self.ids_host}:{self.ids_port}"
        )
        print("=" * 60)


    # ======================================================
    # CONVERSIÓN DE COORDENADAS NMEA
    # ======================================================

    @staticmethod
    def nmea_coord_to_decimal(
        value: str,
        hemisphere: str
    ) -> float:

        if not value:
            raise ValueError(
                "Coordenada NMEA vacía"
            )

        decimal_position = value.find(
            "."
        )

        if decimal_position < 0:
            raise ValueError(
                f"Coordenada NMEA inválida: {value}"
            )

        degree_digits = (
            decimal_position - 2
        )

        degrees = float(
            value[:degree_digits]
        )

        minutes = float(
            value[degree_digits:]
        )

        decimal_value = (
            degrees
            + minutes / 60.0
        )

        if hemisphere in {
            "S",
            "W"
        }:
            decimal_value *= -1

        return decimal_value


    # ======================================================
    # PARSER DE ESTADO
    # ======================================================

    def parse_nmea_state(
        self,
        sentence: str
    ) -> dict:
        """
        Interpreta las sentencias recibidas por PHASMIDA.

        Las sentencias de navegación mantienen el tratamiento
        original del proyecto.

        Las sentencias RPM y XDR relacionadas con la cámara
        de máquinas se delegan al IEC61162StateManager.
        """

        if not sentence.startswith("$"):
            return {}

        try:

            body = sentence[
                1:
            ].split(
                "*",
                1
            )[0]

            fields = body.split(
                ","
            )

            if not fields:
                return {}

            header = fields[0]

            # ==================================================
            # PHSMD - ESTADOS DISCRETOS PHASMIDA
            # ==================================================

            if header == "PHSMD":
                return (
                    self.iec61162_manager.parse_sentence(
                        sentence
                    )
                )

            if len(header) < 5:
                return {}

            sentence_type = header[2:]

            updates: dict = {}

            # ==================================================
            # RMC - POSICIÓN, VELOCIDAD Y RUMBO
            # ==================================================

            if sentence_type == "RMC":

                updates["position"] = {

                    "latitude":
                        self.nmea_coord_to_decimal(
                            fields[3],
                            fields[4]
                        ),

                    "longitude":
                        self.nmea_coord_to_decimal(
                            fields[5],
                            fields[6]
                        )
                }

                updates["navigation"] = {

                    "speed_knots": (
                        float(fields[7])
                        if fields[7]
                        else None
                    ),

                    "course_deg": (
                        float(fields[8])
                        if fields[8]
                        else None
                    )
                }

            # ==================================================
            # GGA - POSICIÓN Y ALTITUD
            # ==================================================

            elif sentence_type == "GGA":

                updates["position"] = {

                    "latitude":
                        self.nmea_coord_to_decimal(
                            fields[2],
                            fields[3]
                        ),

                    "longitude":
                        self.nmea_coord_to_decimal(
                            fields[4],
                            fields[5]
                        ),

                    "altitude_m": (
                        float(fields[9])
                        if fields[9]
                        else None
                    )
                }

            # ==================================================
            # VTG - RUMBO Y VELOCIDAD
            # ==================================================

            elif sentence_type == "VTG":

                updates["navigation"] = {

                    "course_deg": (
                        float(fields[1])
                        if fields[1]
                        else None
                    ),

                    "speed_knots": (
                        float(fields[5])
                        if fields[5]
                        else None
                    )
                }

            # ==================================================
            # HDT / HDG / HDM - HEADING
            # ==================================================

            elif sentence_type in {
                "HDT",
                "HDG",
                "HDM"
            }:

                updates["navigation"] = {

                    "heading_deg": (
                        float(fields[1])
                        if fields[1]
                        else None
                    )
                }

            # ==================================================
            # DBT / DPT - PROFUNDIDAD
            # ==================================================

            elif sentence_type in {
                "DBT",
                "DPT"
            }:

                if sentence_type == "DBT":

                    depth_m = (
                        float(fields[3])
                        if fields[3]
                        else None
                    )

                else:

                    depth_m = (
                        float(fields[1])
                        if fields[1]
                        else None
                    )

                updates["depth"] = {
                    "meters": depth_m
                }

            # ==================================================
            # RPM / XDR - CÁMARA DE MÁQUINAS
            # ==================================================

            elif sentence_type in {
                "RPM",
                "XDR"
            }:

                updates = (
                    self.iec61162_manager.parse_sentence(
                        sentence
                    )
                )

            return updates

        except (
            ValueError,
            IndexError,
            TypeError
        ):

            return {}


    # ======================================================
    # PROCESAMIENTO DE MENSAJES
    # ======================================================

    def process_message(
        self,
        raw_data: bytes,
        source_ip: str
    ) -> None:
        """
        Procesa un datagrama PHASMIDA recibido.

        El mensaje contiene la sentencia NMEA/IEC 61162
        original junto con los metadatos de seguridad
        utilizados por la plataforma.
        """

        try:

            decoded = raw_data.decode(
                "utf-8",
                errors="ignore"
            ).strip()

            message = json.loads(
                decoded
            )

            if not isinstance(
                message,
                dict
            ):
                raise ValueError(
                    "El mensaje recibido no es "
                    "un objeto JSON"
                )

            sentence = str(
                message["nmea"]
            ).strip()

            if not sentence.startswith("$"):
                raise ValueError(
                    "La sentencia recibida no presenta "
                    "un formato NMEA/IEC 61162 válido"
                )

        except (
            UnicodeDecodeError,
            json.JSONDecodeError,
            KeyError,
            TypeError,
            ValueError
        ) as error:

            print(
                f"[CORE ERROR] Mensaje inválido desde "
                f"{source_ip}: {error}",
                flush=True
            )

            return

        # --------------------------------------------------
        # IDENTIFICACIÓN DEL MENSAJE
        # --------------------------------------------------

        header = (
            sentence[1:]
            .split(
                "*",
                1
            )[0]
            .split(
                ",",
                1
            )[0]
        )

        if header == "PHSMD":

            # PHSMD es una extensión propietaria experimental
            # de PHASMIDA y no utiliza la división convencional
            # Talker ID + Sentence Type.
            talker_id = "PHASMIDA"
            sentence_type = "STATE"

        else:

            talker_id = (
                header[:2]
                if len(header) >= 2
                else None
            )

            sentence_type = (
                header[2:]
                if len(header) >= 5
                else None
            )

        # --------------------------------------------------
        # INTERPRETACIÓN DEL ESTADO
        # --------------------------------------------------

        updates = self.parse_nmea_state(
            sentence
        )

        # --------------------------------------------------
        # ACTUALIZACIÓN DEL ESTADO COMPARTIDO
        # --------------------------------------------------

        update_state(
            updates,
            source_ip=source_ip,
            sentence=sentence,
            sentence_type=sentence_type,
            talker_id=talker_id,
            suspicious=False,
            alerts=[]
        )

        # --------------------------------------------------
        # REENVÍO DEL MENSAJE ORIGINAL AL IDS
        # --------------------------------------------------

        try:

            self.forward_socket.sendto(
                raw_data,
                (
                    self.ids_host,
                    self.ids_port
                )
            )

            ids_status = "Forwarded to IDS"

        except (
            socket.gaierror,
            OSError
        ) as error:

            # Durante las pruebas locales puede no existir
            # todavía el contenedor phasmida_ids. El Core
            # continúa funcionando para permitir validar
            # navegación y maquinaria independientemente.
            ids_status = (
                f"IDS unavailable: {error}"
            )

        # --------------------------------------------------
        # LOG DEL CORE
        # --------------------------------------------------

        print(
            f"[CORE RX] {source_ip} | "
            f"Talker={talker_id or 'UNKNOWN'} | "
            f"Type={sentence_type or 'UNKNOWN'} | "
            f"{ids_status}",
            flush=True
        )


    # ======================================================
    # BUCLE PRINCIPAL
    # ======================================================

    def run(
        self
    ) -> None:

        try:

            while True:

                data, address = (
                    self.receive_socket.recvfrom(
                        4096
                    )
                )

                self.process_message(
                    data,
                    address[0]
                )

        except KeyboardInterrupt:

            print(
                "\nPHASMIDA Core detenido.",
                flush=True
            )

        finally:

            self.receive_socket.close()
            self.forward_socket.close()
