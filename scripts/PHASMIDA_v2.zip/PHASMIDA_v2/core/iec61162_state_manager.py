"""
PHASMIDA Core
==============================

IEC 61162 State Manager

Extensión del núcleo original de PHASMIDA destinada al
tratamiento de información procedente de los sistemas de
propulsión y auxiliares de la cámara de máquinas.

Responsabilidades:
    - Interpretar sentencias IEC 61162 asociadas a maquinaria.
    - Procesar sentencias RPM.
    - Procesar transductores XDR.
    - Procesar mensajes propietarios PHSMD.
    - Transformar las medidas recibidas al estado común
      de PHASMIDA.
    - Mantener separada esta funcionalidad del gestor NMEA
      original utilizado para navegación.

Los mensajes PHSMD constituyen una extensión experimental
del entorno PHASMIDA para representar estados discretos
del proceso OT. No se consideran sentencias normalizadas
IEC 61162.
"""

from typing import Any


class IEC61162StateManager:
    """
    Parser de comunicaciones relacionadas con los sistemas
    de maquinaria y propulsión del buque.
    """

    # ======================================================
    # PARSER GENERAL
    # ======================================================

    def parse_sentence(
        self,
        sentence: str
    ) -> dict[str, Any]:
        """
        Interpreta una sentencia recibida y devuelve las
        variables que deben incorporarse al estado global
        de PHASMIDA.
        """

        if not sentence.startswith("$"):
            return {}

        try:
            body = sentence[
                1:
            ].split(
                "*",
                1
            )[0]

            fields = body.split(",")

            if not fields:
                return {}

            header = fields[0]

            # --------------------------------------------------
            # EXTENSIÓN PROPIETARIA PHASMIDA
            # --------------------------------------------------

            if header == "PHSMD":
                return self.parse_phasmida_state(
                    fields
                )

            # --------------------------------------------------
            # IEC 61162 / NMEA
            # --------------------------------------------------

            if len(header) < 5:
                return {}

            sentence_type = header[2:]

            if sentence_type == "RPM":
                return self.parse_rpm(
                    fields
                )

            if sentence_type == "XDR":
                return self.parse_xdr(
                    fields
                )

        except (
            ValueError,
            IndexError,
            TypeError
        ):
            return {}

        return {}

    # ======================================================
    # RPM
    # ======================================================

    @staticmethod
    def parse_rpm(
        fields: list[str]
    ) -> dict[str, Any]:
        """
        Procesa una sentencia RPM.

        Formato utilizado:

            $--RPM,E,x,x.x,x.x,A

        En el simulador PHASMIDA:

            motor 1 -> estribor
            motor 2 -> babor
        """

        if len(fields) < 6:
            return {}

        source = fields[1]

        if source != "E":
            return {}

        engine_number = int(
            fields[2]
        )

        rpm = float(
            fields[3]
        )

        status = fields[5]

        if engine_number == 1:
            side = "starboard"

        elif engine_number == 2:
            side = "port"

        else:
            return {}

        return {
            "propulsion": {
                side: {
                    "running": (
                        status == "A"
                        and rpm > 0.0
                    ),
                    "rpm": rpm
                }
            }
        }

    # ======================================================
    # XDR
    # ======================================================

    @staticmethod
    def parse_xdr(
        fields: list[str]
    ) -> dict[str, Any]:
        """
        Procesa los transductores contenidos en una
        sentencia XDR.

        Cada transductor se representa mediante:

            tipo, valor, unidad, identificador
        """

        updates: dict[str, Any] = {}

        transducer_fields = fields[1:]

        for index in range(
            0,
            len(transducer_fields),
            4
        ):

            group = transducer_fields[
                index:index + 4
            ]

            if len(group) != 4:
                continue

            (
                transducer_type,
                value_text,
                unit,
                identifier
            ) = group

            if not value_text:
                continue

            try:
                value = float(
                    value_text
                )

            except ValueError:
                continue

            # ==============================================
            # PROPULSIÓN - TEMPERATURAS
            # ==============================================

            if identifier == "ENG_PORT_TEMP":

                updates.setdefault(
                    "propulsion",
                    {}
                ).setdefault(
                    "port",
                    {}
                )["temperature_c"] = value

            elif identifier == "ENG_STBD_TEMP":

                updates.setdefault(
                    "propulsion",
                    {}
                ).setdefault(
                    "starboard",
                    {}
                )["temperature_c"] = value

            elif identifier == "COOL_PORT_TEMP":

                updates.setdefault(
                    "propulsion",
                    {}
                ).setdefault(
                    "port",
                    {}
                )["coolant_temperature_c"] = value

            elif identifier == "COOL_STBD_TEMP":

                updates.setdefault(
                    "propulsion",
                    {}
                ).setdefault(
                    "starboard",
                    {}
                )["coolant_temperature_c"] = value

            # ==============================================
            # PROPULSIÓN - PRESIÓN DE ACEITE
            # ==============================================

            elif identifier == "OIL_PORT_PRESS":

                updates.setdefault(
                    "propulsion",
                    {}
                ).setdefault(
                    "port",
                    {}
                )["oil_pressure_bar"] = value

            elif identifier == "OIL_STBD_PRESS":

                updates.setdefault(
                    "propulsion",
                    {}
                ).setdefault(
                    "starboard",
                    {}
                )["oil_pressure_bar"] = value

            # ==============================================
            # PROPULSIÓN - POTENCIA
            # ==============================================

            elif identifier == "ENG_PORT_POWER":

                updates.setdefault(
                    "propulsion",
                    {}
                ).setdefault(
                    "port",
                    {}
                )["power_kw"] = value

            elif identifier == "ENG_STBD_POWER":

                updates.setdefault(
                    "propulsion",
                    {}
                ).setdefault(
                    "starboard",
                    {}
                )["power_kw"] = value

            # ==============================================
            # COMBUSTIBLE
            # ==============================================

            elif identifier == "FUEL_PRESS":

                updates.setdefault(
                    "fuel",
                    {}
                )["pressure_bar"] = value

            elif identifier == "FUEL_TANK_LEVEL":

                updates.setdefault(
                    "fuel",
                    {}
                )["tank_level_percent"] = value

            elif identifier == "FUEL_FLOW":

                updates.setdefault(
                    "fuel",
                    {}
                )["flow_l_min"] = value

            # ==============================================
            # REFRIGERACIÓN
            # ==============================================

            elif identifier == "COOL_PRESS":

                updates.setdefault(
                    "cooling",
                    {}
                )["pressure_bar"] = value

            elif identifier == "COOL_SYS_TEMP":

                updates.setdefault(
                    "cooling",
                    {}
                )["temperature_c"] = value

            elif identifier == "COOL_FLOW":

                updates.setdefault(
                    "cooling",
                    {}
                )["flow_l_min"] = value

            # ==============================================
            # SISTEMA ELÉCTRICO
            # ==============================================

            elif identifier == "GEN_FREQ":

                updates.setdefault(
                    "electrical",
                    {}
                )["frequency_hz"] = value

            elif identifier == "GEN_VOLTAGE":

                updates.setdefault(
                    "electrical",
                    {}
                )["voltage_v"] = value

            elif identifier == "GEN_CURRENT":

                updates.setdefault(
                    "electrical",
                    {}
                )["current_a"] = value

            elif identifier == "GEN_POWER":

                updates.setdefault(
                    "electrical",
                    {}
                )["power_kw"] = value

        return updates

    # ======================================================
    # EXTENSIÓN PROPIETARIA PHASMIDA
    # ======================================================

    @staticmethod
    def parse_phasmida_state(
        fields: list[str]
    ) -> dict[str, Any]:
        """
        Procesa mensajes propietarios de estado PHASMIDA.

        Formato:

            $PHSMD,STATE,IDENTIFICADOR,VALOR*hh

        VALOR:
            1 -> ON / OPEN / RUNNING
            0 -> OFF / CLOSED / STOPPED
        """

        if len(fields) < 4:
            return {}

        message_type = fields[1]
        identifier = fields[2]
        value_text = fields[3]

        if message_type != "STATE":
            return {}

        if value_text not in {
            "0",
            "1"
        }:
            return {}

        state = (
            value_text == "1"
        )

        # ==============================================
        # SISTEMA DE COMBUSTIBLE
        # ==============================================

        if identifier == "FUEL_PORT_PUMP":

            return {
                "fuel": {
                    "port_pump": state
                }
            }

        if identifier == "FUEL_STBD_PUMP":

            return {
                "fuel": {
                    "starboard_pump": state
                }
            }

        if identifier == "FUEL_PORT_VALVE":

            return {
                "fuel": {
                    "port_valve": state
                }
            }

        if identifier == "FUEL_STBD_VALVE":

            return {
                "fuel": {
                    "starboard_valve": state
                }
            }

        # ==============================================
        # SISTEMA DE REFRIGERACIÓN
        # ==============================================

        if identifier == "COOL_PORT_PUMP":

            return {
                "cooling": {
                    "port_pump": state
                }
            }

        if identifier == "COOL_STBD_PUMP":

            return {
                "cooling": {
                    "starboard_pump": state
                }
            }

        # ==============================================
        # SISTEMA ELÉCTRICO
        # ==============================================

        if identifier == "GEN_RUNNING":

            return {
                "electrical": {
                    "generator_running": state
                }
            }

        return {}