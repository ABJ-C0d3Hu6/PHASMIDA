import json
import os
import random
from datetime import datetime, timezone

import folium
import pandas as pd
import streamlit as st
from streamlit_folium import st_folium


# ==========================================================
# CONFIGURACIÓN
# ==========================================================

STATE_FILE = os.getenv(
    "PHASMIDA_STATE_FILE",
    "events/nmea_state.json"
)

DEFAULT_SHIP = {
    "name": "Kontiki",
    "lat": 38.335,
    "lon": -0.430,
    "heading": 75.0,
    "course": 75.0,
    "speed": 10.5,
    "updated_at": None,
    "source_ip": None,
    "sentence_type": None
}


# ==========================================================
# LECTURA DEL ESTADO PHASMIDA CORE
# ==========================================================

def load_nmea_state() -> dict:
    if not os.path.exists(STATE_FILE):
        return {}

    try:
        with open(STATE_FILE, "r", encoding="utf-8") as file:
            state = json.load(file)

        return state if isinstance(state, dict) else {}

    except (OSError, json.JSONDecodeError):
        return {}


def build_own_ship(state: dict) -> dict:
    position = state.get("position", {})
    navigation = state.get("navigation", {})

    latitude = position.get("latitude")
    longitude = position.get("longitude")

    heading = navigation.get("heading_deg")
    course = navigation.get("course_deg")
    speed = navigation.get("speed_knots")

    return {
        "name": "Kontiki",
        "lat": (
            float(latitude)
            if latitude is not None
            else DEFAULT_SHIP["lat"]
        ),
        "lon": (
            float(longitude)
            if longitude is not None
            else DEFAULT_SHIP["lon"]
        ),
        "heading": (
            float(heading)
            if heading is not None
            else float(course)
            if course is not None
            else DEFAULT_SHIP["heading"]
        ),
        "course": (
            float(course)
            if course is not None
            else float(heading)
            if heading is not None
            else DEFAULT_SHIP["course"]
        ),
        "speed": (
            float(speed)
            if speed is not None
            else DEFAULT_SHIP["speed"]
        ),
        "updated_at": state.get("updated_at"),
        "source_ip": state.get("source_ip"),
        "sentence_type": state.get("last_sentence_type")
    }


def state_is_stale(updated_at: str | None, max_age_seconds: int = 10) -> bool:
    if not updated_at:
        return True

    try:
        state_time = datetime.fromisoformat(updated_at)
        now = datetime.now(timezone.utc)

        return abs((now - state_time).total_seconds()) > max_age_seconds

    except ValueError:
        return True


# ==========================================================
# AIS SIMULADO
# ==========================================================

@st.cache_data(ttl=30)
def generate_ais_targets() -> pd.DataFrame:
    targets = []

    for index in range(6):
        targets.append({
            "mmsi": f"224000{index + 1}",
            "name": f"AIS_TARGET_{index + 1}",
            "lat": 38.30 + random.uniform(-0.05, 0.09),
            "lon": -0.42 + random.uniform(-0.08, 0.12),
            "speed": round(random.uniform(3, 18), 1),
            "course": round(random.uniform(0, 359), 1),
            "status": random.choice([
                "normal",
                "normal",
                "sospechoso"
            ])
        })

    return pd.DataFrame(targets)


# ==========================================================
# INTERFAZ
# ==========================================================

st.set_page_config(
    page_title="ECDIS PHASMIDA",
    layout="wide"
)

st.title("ECDIS Simulado")
st.caption(
    "Sistema de Información y Visualización de Cartas Electrónicas"
)
st.caption("Integrado con PHASMIDA Core")

state = load_nmea_state()
own_ship = build_own_ship(state)
df_ais = generate_ais_targets()

stale_state = state_is_stale(own_ship["updated_at"])

if not state:
    st.warning(
        "No se ha encontrado el estado NMEA compartido. "
        "Se muestran valores de respaldo."
    )
elif stale_state:
    st.warning(
        "El estado NMEA no se ha actualizado recientemente. "
        "La visualización puede mostrar datos antiguos."
    )
else:
    st.success(
        "ECDIS conectado correctamente a PHASMIDA Core."
    )


# ==========================================================
# RUTA PLANIFICADA
# ==========================================================

route = [
    [own_ship["lat"], own_ship["lon"]],
    [own_ship["lat"] + 0.010, own_ship["lon"] + 0.040],
    [own_ship["lat"] + 0.025, own_ship["lon"] + 0.080],
    [own_ship["lat"] + 0.045, own_ship["lon"] + 0.120]
]


# ==========================================================
# MAPA
# ==========================================================

m = folium.Map(
    location=[own_ship["lat"], own_ship["lon"]],
    zoom_start=11,
    tiles="OpenStreetMap"
)

folium.TileLayer(
    tiles="https://tiles.openseamap.org/seamark/{z}/{x}/{y}.png",
    attr="OpenSeaMap",
    name="Seamarks",
    overlay=True,
    control=True
).add_to(m)

folium.Marker(
    location=[own_ship["lat"], own_ship["lon"]],
    popup=(
        f"<b>{own_ship['name']}</b><br>"
        f"Rumbo: {own_ship['heading']:.1f}º<br>"
        f"Curso: {own_ship['course']:.1f}º<br>"
        f"Velocidad: {own_ship['speed']:.1f} kn<br>"
        f"Fuente: {own_ship['source_ip'] or 'desconocida'}<br>"
        f"Última sentencia: "
        f"{own_ship['sentence_type'] or 'desconocida'}"
    ),
    tooltip="Buque propio",
    icon=folium.Icon(
        color="blue",
        icon="ship",
        prefix="fa"
    )
).add_to(m)

folium.PolyLine(
    route,
    color="blue",
    weight=3,
    opacity=0.8,
    tooltip="Ruta planificada"
).add_to(m)

for _, row in df_ais.iterrows():
    color = (
        "red"
        if row["status"] == "sospechoso"
        else "green"
    )

    folium.Marker(
        location=[row["lat"], row["lon"]],
        popup=(
            f"<b>{row['name']}</b><br>"
            f"MMSI: {row['mmsi']}<br>"
            f"Velocidad: {row['speed']} kn<br>"
            f"Curso: {row['course']}º<br>"
            f"Estado: {row['status']}"
        ),
        tooltip=row["name"],
        icon=folium.Icon(
            color=color,
            icon="location-dot",
            prefix="fa"
        )
    ).add_to(m)

folium.Circle(
    location=[
        own_ship["lat"] + 0.020,
        own_ship["lon"] + 0.065
    ],
    radius=2500,
    color="red",
    fill=True,
    fill_opacity=0.15,
    tooltip="Zona de alerta"
).add_to(m)

folium.LayerControl().add_to(m)


# ==========================================================
# MÉTRICAS
# ==========================================================

col1, col2, col3, col4 = st.columns(4)

col1.metric(
    "Buque propio",
    own_ship["name"]
)

col2.metric(
    "Velocidad",
    f"{own_ship['speed']:.1f} kn"
)

col3.metric(
    "Rumbo",
    f"{own_ship['heading']:.1f}º"
)

col4.metric(
    "Blancos AIS",
    len(df_ais)
)

st_folium(
    m,
    width=None,
    height=650
)


# ==========================================================
# ESTADO NMEA
# ==========================================================

st.subheader("Estado NMEA del buque")

state_table = pd.DataFrame([
    {
        "Parámetro": "Latitud",
        "Valor": own_ship["lat"]
    },
    {
        "Parámetro": "Longitud",
        "Valor": own_ship["lon"]
    },
    {
        "Parámetro": "Velocidad",
        "Valor": f"{own_ship['speed']:.1f} kn"
    },
    {
        "Parámetro": "Curso",
        "Valor": f"{own_ship['course']:.1f}º"
    },
    {
        "Parámetro": "Rumbo",
        "Valor": f"{own_ship['heading']:.1f}º"
    },
    {
        "Parámetro": "Última sentencia",
        "Valor": own_ship["sentence_type"] or "N/D"
    },
    {
        "Parámetro": "Fuente",
        "Valor": own_ship["source_ip"] or "N/D"
    },
    {
        "Parámetro": "Actualización",
        "Valor": own_ship["updated_at"] or "N/D"
    }
])

st.dataframe(
    state_table,
    use_container_width=True,
    hide_index=True
)

st.subheader("Blancos AIS simulados")
st.dataframe(
    df_ais,
    use_container_width=True,
    hide_index=True
)