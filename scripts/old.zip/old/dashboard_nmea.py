import time
import pandas as pd
import altair as alt
import streamlit as st
from datetime import datetime

NMEA_FILE = "tramas_nmea.txt"

st.set_page_config(page_title="Dashboard NMEA", layout="wide")
st.title("Dashboard NMEA 0183")
st.caption("Visualización simple de tramas NMEA simuladas")


def load_nmea_file():
    rows = []

    try:
        with open(NMEA_FILE, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except FileNotFoundError:
        return pd.DataFrame()

    for i, line in enumerate(lines):
        sentence = line.strip()

        if not sentence:
            continue

        try:
            body = sentence.replace("$", "").split("*")[0]
            fields = body.split(",")
            header = fields[0]

            talker = header[:2]
            sentence_type = header[2:]

            rows.append({
                "index": i,
                "timestamp": datetime.now(),
                "raw": sentence,
                "talker": talker,
                "sentence_type": sentence_type
            })

        except Exception:
            rows.append({
                "index": i,
                "timestamp": datetime.now(),
                "raw": sentence,
                "talker": "UNKNOWN",
                "sentence_type": "UNKNOWN"
            })

    return pd.DataFrame(rows)


placeholder = st.empty()

while True:
    df = load_nmea_file()

    with placeholder.container():
        if df.empty:
            st.warning("No hay tramas todavía. Ejecuta primero nmea_generator.py")
        else:
            col1, col2, col3 = st.columns(3)

            col1.metric("Tramas totales", len(df))
            col2.metric("Tipos de trama", df["sentence_type"].nunique())
            col3.metric("Talkers detectados", df["talker"].nunique())

            st.subheader("Tramas por tipo")

            chart_data = df.groupby("sentence_type").size().reset_index(name="count")

            chart = alt.Chart(chart_data).mark_bar().encode(
                x=alt.X("sentence_type:N", title="Tipo de trama"),
                y=alt.Y("count:Q", title="Número de tramas"),
                tooltip=["sentence_type", "count"]
            ).properties(height=350)

            st.altair_chart(chart, use_container_width=True)

            st.subheader("Evolución de tramas generadas")

            line_chart = alt.Chart(df).mark_line(point=True).encode(
                x=alt.X("index:Q", title="Orden de llegada"),
                y=alt.Y("sentence_type:N", title="Tipo de trama"),
                tooltip=["index", "sentence_type", "raw"]
            ).properties(height=300)

            st.altair_chart(line_chart, use_container_width=True)

            st.subheader("Últimas tramas NMEA")

            st.dataframe(
                df.tail(20)[["index", "talker", "sentence_type", "raw"]],
                use_container_width=True
            )

    time.sleep(2)