#!/usr/bin/env python3
import argparse
import json
import socket
from datetime import datetime, timezone


def calculate_checksum(sentence_body: str) -> str:
    checksum = 0
    for char in sentence_body:
        checksum ^= ord(char)
    return f"{checksum:02X}"


def validate_nmea_sentence(sentence: str) -> tuple[bool, str]:
    sentence = sentence.strip()

    if not sentence.startswith("$"):
        return False, "La trama no empieza por $"

    if "*" not in sentence:
        return False, "La trama no contiene checksum"

    body, received_checksum = sentence[1:].split("*", 1)
    received_checksum = received_checksum[:2].upper()

    calculated_checksum = calculate_checksum(body)

    if calculated_checksum != received_checksum:
        return False, f"Checksum inválido: recibido={received_checksum}, calculado={calculated_checksum}"

    return True, "OK"


def classify_sentence(talker: str, sentence_type: str) -> str:
    full_type = f"{talker}{sentence_type}"

    if sentence_type in ["RMC", "GGA", "GLL", "VTG"]:
        return "GNSS/GPS"

    if sentence_type in ["HDG", "HDT", "HDM"]:
        return "Rumbo/Compás"

    if sentence_type in ["DBT", "DPT"]:
        return "Sonda/Profundidad"

    if sentence_type in ["MWV", "VWR"]:
        return "Viento"

    if sentence_type in ["RSA"]:
        return "Timón"

    if sentence_type in ["RPM"]:
        return "Motor/Propulsión"

    if talker in ["AI", "AB"]:
        return "AIS"

    return "Desconocido"


def parse_nmea_sentence(sentence: str, source: str = "file") -> dict:
    sentence = sentence.strip()
    valid, validation_message = validate_nmea_sentence(sentence)

    event = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "source": source,
        "raw_sentence": sentence,
        "valid": valid,
        "validation_message": validation_message,
        "protocol": "NMEA 0183"
    }

    if not sentence.startswith("$") or "," not in sentence:
        event["error"] = "Formato NMEA no válido"
        return event

    try:
        body = sentence[1:].split("*")[0]
        fields = body.split(",")

        header = fields[0]
        talker = header[:2]
        sentence_type = header[2:]

        event.update({
            "talker": talker,
            "sentence_type": sentence_type,
            "category": classify_sentence(talker, sentence_type),
            "fields": fields[1:]
        })

        event.update(extract_known_fields(talker, sentence_type, fields[1:]))

    except Exception as e:
        event["error"] = str(e)

    return event


def extract_known_fields(talker: str, sentence_type: str, fields: list[str]) -> dict:
    data = {}

    try:
        if sentence_type == "RMC":
            data.update({
                "utc_time": fields[0],
                "status": fields[1],
                "latitude": fields[2],
                "latitude_dir": fields[3],
                "longitude": fields[4],
                "longitude_dir": fields[5],
                "speed_knots": safe_float(fields[6]),
                "course_degrees": safe_float(fields[7]),
                "date": fields[8]
            })

        elif sentence_type == "GGA":
            data.update({
                "utc_time": fields[0],
                "latitude": fields[1],
                "latitude_dir": fields[2],
                "longitude": fields[3],
                "longitude_dir": fields[4],
                "fix_quality": safe_int(fields[5]),
                "num_satellites": safe_int(fields[6]),
                "hdop": safe_float(fields[7]),
                "altitude_m": safe_float(fields[8])
            })

        elif sentence_type == "HDG":
            data.update({
                "heading_degrees": safe_float(fields[0])
            })

        elif sentence_type == "DBT":
            data.update({
                "depth_feet": safe_float(fields[0]),
                "depth_meters": safe_float(fields[2]),
                "depth_fathoms": safe_float(fields[4])
            })

        elif sentence_type == "MWV":
            data.update({
                "wind_angle": safe_float(fields[0]),
                "reference": fields[1],
                "wind_speed": safe_float(fields[2]),
                "wind_speed_unit": fields[3],
                "status": fields[4]
            })

    except IndexError:
        data["parse_warning"] = "Campos incompletos para este tipo de trama"

    return data


def safe_float(value: str):
    try:
        return float(value)
    except (ValueError, TypeError):
        return None


def safe_int(value: str):
    try:
        return int(value)
    except (ValueError, TypeError):
        return None


def read_from_file(input_file: str, output_file: str):
    with open(input_file, "r", encoding="utf-8") as file_in, \
         open(output_file, "w", encoding="utf-8") as file_out:

        for line in file_in:
            sentence = line.strip()
            if not sentence:
                continue

            event = parse_nmea_sentence(sentence, source="file")
            file_out.write(json.dumps(event, ensure_ascii=False) + "\n")
            print(json.dumps(event, indent=2, ensure_ascii=False))

    print(f"\nEventos JSON guardados en: {output_file}")


def read_from_udp(host: str, port: int, output_file: str):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((host, port))

    print(f"Escuchando tráfico NMEA UDP en {host}:{port}")
    print("Pulsa Ctrl+C para detener.\n")

    with open(output_file, "a", encoding="utf-8") as file_out:
        try:
            while True:
                data, addr = sock.recvfrom(4096)
                sentence = data.decode(errors="ignore").strip()

                event = parse_nmea_sentence(sentence, source=f"{addr[0]}:{addr[1]}")
                file_out.write(json.dumps(event, ensure_ascii=False) + "\n")
                file_out.flush()

                print(json.dumps(event, indent=2, ensure_ascii=False))

        except KeyboardInterrupt:
            print(f"\nCaptura detenida. Eventos guardados en: {output_file}")


def main():
    parser = argparse.ArgumentParser(
        description="Lector de tramas NMEA 0183 desde fichero o UDP y conversión a JSON"
    )

    parser.add_argument(
        "--mode",
        choices=["file", "udp"],
        required=True,
        help="Modo de lectura: file o udp"
    )

    parser.add_argument(
        "--input",
        default="tramas_nmea.txt",
        help="Fichero de entrada en modo file"
    )

    parser.add_argument(
        "--output",
        default="eventos_nmea.jsonl",
        help="Fichero de salida JSON Lines"
    )

    parser.add_argument(
        "--host",
        default="0.0.0.0",
        help="Host de escucha UDP"
    )

    parser.add_argument(
        "--port",
        type=int,
        default=10110,
        help="Puerto UDP de escucha NMEA"
    )

    args = parser.parse_args()

    if args.mode == "file":
        read_from_file(args.input, args.output)

    elif args.mode == "udp":
        read_from_udp(args.host, args.port, args.output)


if __name__ == "__main__":
    main()