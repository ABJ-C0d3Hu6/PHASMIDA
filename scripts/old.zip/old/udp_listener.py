import socket

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(("127.0.0.1", 10110))

print("Escuchando UDP 127.0.0.1:10110")

while True:
    data, addr = sock.recvfrom(4096)
    print(addr, data.decode(errors="ignore"))