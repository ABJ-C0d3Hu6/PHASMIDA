#!/usr/bin/env python3

import json
import math
from datetime import datetime
from collections import deque, defaultdict

INPUT_FILE = "eventos_nmea.json"
OUTPUT_FILE = "alertas_nmea.json"

AUTHORIZED_SOURCES = {
    "file",
    "127.0.0.1",
    "localhost"
}

MAX_MESSAGES_PER_SECOND = 20
MAX_HEADING_CHANGE_DEGREES = 45
MAX_SPEED_KNOTS = 50


def parse_timestamp(ts: str):
    try:
        return datetime.fromisoformat(ts)
    except Exception:
        return None


def normalize_source(source: str) -> str:
    if ":" in source:
        return source.split(":")[0]
    return source


def nmea_latlon_to_decimal(value, direction):
    """
    Convierte coordenadas NMEA ddmm.mmmm a decimal.
    Ejemplo latitud: 3800.000,N → 38.0000
    Ejemplo longitud: 00030.000,W → -0.5000
    """
    if not value or not direction:
        return None

    try:
        raw = float(value)

        degrees = int(raw // 100)
        minutes = raw - (degrees * 100)

        decimal = degrees + minutes / 60

        if direction in ["S", "W"]:
            decimal *= -1

        return decimal

    except Exception:
        return None


def haversine_nm(lat1, lon1, lat2, lon2):
    """
    Distancia entre dos puntos en millas náuticas.
    """
    radius_nm = 3440.065

    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)

    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)

    a = (
        math.sin(delta_phi / 2) ** 2
        + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2) ** 2
    )

    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    return radius_nm * c


def angular_difference(a, b):
    """
    Diferencia mínima entre dos ángulos.
    """
    return abs((a - b + 180) % 360 - 180)


def create_alert(event, alert_type, severity, message):
    return {
        "timestamp": event.get("timestamp"),
        "alert_type": alert_type,
        "severity": severity,
        "message": message,
        "source": event.get("source"),
        "protocol": event.get("protocol"),
        "sentence_type": event.get("sentence_type"),
        "category": event.get("category"),
        "raw_sentence": event.get("raw_sentence")
    }


def detect_anomalies(input_file, output_file):
    last_heading = None
    last_position = None
    message_times = defaultdict(deque)

    alerts = []

    with open(input_file, "r", encoding="utf-8") as file_in, \
         open(output_file, "w", encoding="utf-8") as file_out:

        for line in file_in:
            if not line.strip():
                continue

            event = json.loads(line)
            event_time = parse_timestamp(event.get("timestamp", ""))

            if event_time is None:
                continue

            source = normalize_source(event.get("source", ""))

            # 1. Checksum inválido
            if event.get("valid") is False:
                alerts.append(
                    create_alert(
                        event,
                        "invalid_checksum",
                        "medium",
                        "Trama NMEA con checksum inválido"
                    )
                )

            # 2. Fuente no autorizada
            if source not in AUTHORIZED_SOURCES:
                alerts.append(
                    create_alert(
                        event,
                        "unauthorized_source",
                        "high",
                        f"Trama recibida desde fuente no autorizada: {source}"
                    )
                )

            # 3. Flood / DoS
            timestamps = message_times[source]
            timestamps.append(event_time)

            while timestamps and (event_time - timestamps[0]).total_seconds() > 1:
                timestamps.popleft()

            if len(timestamps) > MAX_MESSAGES_PER_SECOND:
                alerts.append(
                    create_alert(
                        event,
                        "nmea_flood",
                        "high",
                        f"Exceso de tráfico NMEA detectado: {len(timestamps)} tramas/s"
                    )
                )

            # 4. Cambio brusco de rumbo
            heading = event.get("heading_degrees")

            if heading is not None:
                if last_heading is not None:
                    diff = angular_difference(heading, last_heading)

                    if diff > MAX_HEADING_CHANGE_DEGREES:
                        alerts.append(
                            create_alert(
                                event,
                                "heading_spoofing",
                                "high",
                                f"Cambio brusco de rumbo detectado: {last_heading:.1f}º → {heading:.1f}º"
                            )
                        )

                last_heading = heading

            # 5. Salto imposible GPS
            if event.get("sentence_type") in ["RMC", "GGA"]:
                lat = nmea_latlon_to_decimal(
                    event.get("latitude"),
                    event.get("latitude_dir")
                )
                lon = nmea_latlon_to_decimal(
                    event.get("longitude"),
                    event.get("longitude_dir")
                )

                if lat is not None and lon is not None:
                    current_position = {
                        "lat": lat,
                        "lon": lon,
                        "time": event_time
                    }

                    if last_position is not None:
                        distance_nm = haversine_nm(
                            last_position["lat"],
                            last_position["lon"],
                            current_position["lat"],
                            current_position["lon"]
                        )

                        delta_hours = (
                            current_position["time"] - last_position["time"]
                        ).total_seconds() / 3600

                        if delta_hours > 0:
                            estimated_speed = distance_nm / delta_hours

                            if estimated_speed > MAX_SPEED_KNOTS:
                                alerts.append(
                                    create_alert(
                                        event,
                                        "gps_spoofing",
                                        "critical",
                                        f"Salto GPS imposible detectado: velocidad estimada {estimated_speed:.1f} kn"
                                    )
                                )

                    last_position = current_position

        for alert in alerts:
            file_out.write(json.dumps(alert, ensure_ascii=False) + "\n")
            print(json.dumps(alert, indent=2, ensure_ascii=False))

    print(f"\nAlertas generadas: {len(alerts)}")
    print(f"Guardadas en: {output_file}")


if __name__ == "__main__":
    detect_anomalies(INPUT_FILE, OUTPUT_FILE)