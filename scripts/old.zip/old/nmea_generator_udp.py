import hashlib
import hmac
import json
import os
import random
import socket
import time
from datetime import datetime, timezone


# ==========================================================
# CONFIGURACIÓN
# ==========================================================

CORE_HOST = os.getenv("PHASMIDA_CORE_HOST", "phasmida_core")
CORE_PORT = int(os.getenv("PHASMIDA_CORE_PORT", "10120"))

SEND_INTERVAL = 1.0

SECRET_KEY = b"PHASMIDA_SECRET_2026"


# ==========================================================
# FUNCIONES NMEA
# ==========================================================

def checksum(body: str) -> str:
    value = 0

    for character in body:
        value ^= ord(character)

    return f"{value:02X}"


def build(body: str) -> str:
    return f"${body}*{checksum(body)}"


def generate_rmc() -> str:
    now = datetime.now(timezone.utc)

    body = (
        f"GPRMC,{now.strftime('%H%M%S')},A,"
        f"3800.000,N,00030.000,W,"
        f"{random.uniform(5, 15):.1f},"
        f"{random.uniform(80, 100):.1f},"
        f"{now.strftime('%d%m%y')},,,A"
    )

    return build(body)


def generate_gga() -> str:
    now = datetime.now(timezone.utc)

    body = (
        f"GPGGA,{now.strftime('%H%M%S')},"
        f"3800.000,N,00030.000,W,"
        f"1,{random.randint(6, 12)},1.0,15.0,M,0.0,M,,"
    )

    return build(body)


# ==========================================================
# MENSAJE SEGURO PHASMIDA
# ==========================================================

def calculate_hmac(
    nmea_sentence: str,
    timestamp: str,
    sensor: str
) -> str:

    payload = f"{nmea_sentence}|{timestamp}|{sensor}"

    return hmac.new(
        SECRET_KEY,
        payload.encode("utf-8"),
        hashlib.sha256
    ).hexdigest()


def build_secure_message(nmea_sentence: str) -> dict:
    timestamp = datetime.now(timezone.utc).isoformat()
    sensor = "gps_node"

    signature = calculate_hmac(
        nmea_sentence,
        timestamp,
        sensor
    )

    return {
        "sensor": sensor,
        "timestamp": timestamp,
        "nmea": nmea_sentence,
        "hmac": signature
    }


# ==========================================================
# EJECUCIÓN
# ==========================================================

def main() -> None:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    print(
        f"GPS node enviando NMEA seguro a "
        f"PHASMIDA Core ({CORE_HOST}:{CORE_PORT})",
        flush=True
    )

    try:
        while True:
            sentence = random.choice([
                generate_rmc(),
                generate_gga()
            ])

            message = build_secure_message(sentence)
            data = json.dumps(message).encode("utf-8")

            sock.sendto(
                data,
                (CORE_HOST, CORE_PORT)
            )

            print(
                f"[TX CORE] {sentence}",
                flush=True
            )

            time.sleep(SEND_INTERVAL)

    except KeyboardInterrupt:
        print("\nGPS node detenido.", flush=True)

    finally:
        sock.close()


if __name__ == "__main__":
    main()
